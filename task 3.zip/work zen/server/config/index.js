require('dotenv').config();
const crypto = require('crypto');
const env = process.env.NODE_ENV || 'development';
let jwtSecret = process.env.JWT_SECRET;
if (!jwtSecret || jwtSecret.startsWith('replace_with')) {
  if (env === 'production') throw new Error('JWT_SECRET must be set in production');
  jwtSecret = crypto.randomBytes(32).toString('hex');
  if (env !== 'test') console.warn('[config] JWT_SECRET not set - using a temporary secret (sessions reset on restart).');
}
module.exports = {
  env,
  port: +process.env.PORT || 5000,
  mongoUri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/workzen',
  jwtSecret,
  clientUrl: process.env.CLIENT_URL || 'http://localhost:5000',
  tz: process.env.APP_TIMEZONE || 'UTC',
  workload: { maxOpen: +process.env.WORKLOAD_MAX_OPEN || 6, maxOverdue: +process.env.WORKLOAD_MAX_OVERDUE || 2 },
  // Project health formula: weights sum to 100. Edit here to tune the score.
  health: { weights: { completion: 40, overdue: 30, upcoming: 15, schedule: 15 }, healthy: 75, attention: 50 },
  focus: { focus: 1500, short_break: 300, long_break: 900, graceSeconds: 300 },
};
