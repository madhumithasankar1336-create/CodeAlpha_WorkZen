const mongoose = require('mongoose');
const config = require('./index');
module.exports = async function connectDB(uri = config.mongoUri) {
  mongoose.set('strictQuery', true);
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log('[db] MongoDB connected');
  } catch (err) {
    console.error('[db] Could not connect to MongoDB at', uri.replace(/\/\/.*@/, '//***@'));
    console.error('[db] Start MongoDB (see README "MongoDB setup") or fix MONGODB_URI. Reason:', err.message);
    throw err;
  }
};
