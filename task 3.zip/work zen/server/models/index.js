const mongoose = require('mongoose');
const { Schema } = mongoose;
const ref = (r, o = {}) => ({ type: Schema.Types.ObjectId, ref: r, ...o });

const STATUSES = ['To Do', 'In Progress', 'In Review', 'Completed'];
const PRIORITIES = ['Low', 'Medium', 'High', 'Urgent'];
const PROJECT_STATUSES = ['Planning', 'Active', 'On Hold', 'Completed'];
const ROLES = ['owner', 'admin', 'member'];
const NOTIFICATION_TYPES = ['task_assigned', 'task_updated', 'comment', 'project_invite', 'deadline', 'badge'];

const userSchema = new Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 60 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true, select: false },
  avatarColor: { type: String, default: '#8B5CF6', match: /^#[0-9a-fA-F]{6}$/ },
}, { timestamps: true });
userSchema.set('toJSON', { transform: (d, r) => { delete r.passwordHash; delete r.__v; return r; } });

const projectSchema = new Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 80 },
  description: { type: String, default: '', maxlength: 1000 },
  owner: ref('User', { required: true }),
  members: [{ _id: false, user: ref('User', { required: true }), role: { type: String, enum: ROLES, default: 'member' }, addedAt: { type: Date, default: Date.now } }],
  startDate: Date,
  deadline: Date,
  status: { type: String, enum: PROJECT_STATUSES, default: 'Active' },
}, { timestamps: true });
projectSchema.index({ 'members.user': 1 });

const taskSchema = new Schema({
  title: { type: String, required: true, trim: true, minlength: 1, maxlength: 120 },
  description: { type: String, default: '', maxlength: 2000 },
  project: ref('Project', { required: true, index: true }),
  creator: ref('User', { required: true }),
  assignee: ref('User', { default: null }),
  status: { type: String, enum: STATUSES, default: 'To Do' },
  priority: { type: String, enum: PRIORITIES, default: 'Medium' },
  startDate: Date,
  dueDate: Date,
  completedAt: Date,
}, { timestamps: true });
taskSchema.index({ project: 1, status: 1 });
taskSchema.index({ assignee: 1, status: 1 });
taskSchema.index({ dueDate: 1 });

const commentSchema = new Schema({
  task: ref('Task', { required: true }), project: ref('Project', { required: true }), author: ref('User', { required: true }),
  text: { type: String, required: true, trim: true, minlength: 1, maxlength: 1000 },
}, { timestamps: true });
commentSchema.index({ task: 1, createdAt: 1 });

const notificationSchema = new Schema({
  recipient: ref('User', { required: true }), type: { type: String, enum: NOTIFICATION_TYPES, required: true },
  message: { type: String, required: true, maxlength: 300 }, project: ref('Project'), task: ref('Task'),
  read: { type: Boolean, default: false }, dedupeKey: { type: String, unique: true, sparse: true },
}, { timestamps: true });
notificationSchema.index({ recipient: 1, read: 1, createdAt: -1 });

const activitySchema = new Schema({
  project: ref('Project', { required: true }), user: ref('User', { required: true }), action: { type: String, required: true, maxlength: 200 },
  task: ref('Task'), createdAt: { type: Date, default: Date.now },
});
activitySchema.index({ project: 1, createdAt: -1 });
activitySchema.index({ task: 1, createdAt: 1 });

const focusSchema = new Schema({
  user: ref('User', { required: true }), task: ref('Task', { default: null }),
  type: { type: String, enum: ['focus', 'short_break', 'long_break'], default: 'focus' },
  plannedSeconds: { type: Number, required: true }, startedAt: { type: Date, default: Date.now }, endedAt: Date,
  pausedAt: Date, pausedMs: { type: Number, default: 0 },
  status: { type: String, enum: ['running', 'completed', 'abandoned'], default: 'running' },
});
focusSchema.index({ user: 1, startedAt: -1 });

const achievementSchema = new Schema({ user: ref('User', { required: true }), badge: { type: String, required: true }, awardedAt: { type: Date, default: Date.now } });
achievementSchema.index({ user: 1, badge: 1 }, { unique: true });

module.exports = {
  STATUSES, PRIORITIES, PROJECT_STATUSES, ROLES,
  User: mongoose.model('User', userSchema), Project: mongoose.model('Project', projectSchema), Task: mongoose.model('Task', taskSchema),
  Comment: mongoose.model('Comment', commentSchema), Notification: mongoose.model('Notification', notificationSchema),
  Activity: mongoose.model('Activity', activitySchema), FocusSession: mongoose.model('FocusSession', focusSchema), Achievement: mongoose.model('Achievement', achievementSchema),
};
