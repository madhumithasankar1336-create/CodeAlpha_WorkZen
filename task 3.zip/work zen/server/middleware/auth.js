const jwt = require('jsonwebtoken');
const config = require('../config');
const { User } = require('../models');
const { HttpError, asyncH } = require('../utils/http');

exports.authenticate = asyncH(async (req, res, next) => {
  const token = req.cookies && req.cookies.wz_token;
  if (!token) throw new HttpError(401, 'Authentication required');
  let payload;
  try { payload = jwt.verify(token, config.jwtSecret); } catch { throw new HttpError(401, 'Session expired. Please log in again.'); }
  const user = await User.findById(payload.id);
  if (!user) throw new HttpError(401, 'Account no longer exists');
  req.user = user;
  next();
});

// Double-submit CSRF: state-changing requests that carry the session cookie must echo the wz_csrf cookie in a header.
exports.csrf = (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (!req.cookies || !req.cookies.wz_token) return next();
  const header = req.get('x-csrf-token');
  if (!header || header !== req.cookies.wz_csrf) return next(new HttpError(403, 'Invalid or missing CSRF token'));
  next();
};
