const { validationResult } = require('express-validator');
class HttpError extends Error { constructor(status, message, errors) { super(message); this.status = status; this.errors = errors; } }
const asyncH = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const ok = (res, data, status = 200) => res.status(status).json({ success: true, data });
const validate = (req, res, next) => {
  const r = validationResult(req);
  if (r.isEmpty()) return next();
  const errors = r.array().map((e) => ({ field: e.path, message: e.msg }));
  res.status(422).json({ success: false, message: errors[0].message, errors });
};
const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
module.exports = { HttpError, asyncH, ok, validate, escapeRegex };
