// Date strategy: all "day" logic (today, overdue, streaks) uses ONE configurable IANA timezone (APP_TIMEZONE).
// Due/start dates are stored at 12:00 UTC of the chosen calendar day so they never shift days in nearby zones.
const config = require('../config');
const dayKey = (d, tz = config.tz) => new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(d));
const diffKeys = (a, b) => Math.round((Date.parse(b) - Date.parse(a)) / 864e5);
const daysUntil = (due, now = new Date()) => diffKeys(dayKey(now), dayKey(due));
const toDate = (s) => (s ? new Date(`${String(s).slice(0, 10)}T12:00:00Z`) : null);
const addDaysKey = (key, n) => new Date(Date.parse(key) + n * 864e5).toISOString().slice(0, 10);
module.exports = { dayKey, diffKeys, daysUntil, toDate, addDaysKey };
