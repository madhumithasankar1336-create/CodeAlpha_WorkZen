const mongoose = require('mongoose');
const { Notification, Task } = require('../models');
const { HttpError, asyncH, ok } = require('../utils/http');
const { notify } = require('../services/notify');
const { dayKey, daysUntil } = require('../utils/dates');
const { accessibleProjectIds } = require('../services/access');

// Deadline reminders are generated lazily (one per task per day thanks to dedupeKey) - no cron needed.
async function deadlineReminders(user) {
  const ids = await accessibleProjectIds(user._id);
  const soon = new Date(Date.now() + 3 * 864e5);
  const tasks = await Task.find({ assignee: user._id, project: { $in: ids }, status: { $ne: 'Completed' }, dueDate: { $ne: null, $lte: soon } }).limit(50);
  const today = dayKey(new Date());
  for (const t of tasks) {
    const d = daysUntil(t.dueDate);
    if (d > 1) continue;
    const msg = d < 0 ? `"${t.title}" is overdue` : d === 0 ? `"${t.title}" is due today` : `"${t.title}" is due tomorrow`;
    await notify({ recipient: user._id, type: 'deadline', message: msg, project: t.project, task: t._id, key: `deadline:${t._id}:${user._id}:${today}:${d < 0 ? 'o' : d}` });
  }
}
exports.list = asyncH(async (req, res) => {
  await deadlineReminders(req.user);
  const q = { recipient: req.user._id };
  if (req.query.unread === '1') q.read = false;
  const items = await Notification.find(q).sort({ createdAt: -1 }).limit(100).lean();
  ok(res, { items, unread: await Notification.countDocuments({ recipient: req.user._id, read: false }) });
});
exports.unread = asyncH(async (req, res) => { await deadlineReminders(req.user); ok(res, { unread: await Notification.countDocuments({ recipient: req.user._id, read: false }) }); });
exports.markRead = asyncH(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Notification not found');
  const n = await Notification.findOneAndUpdate({ _id: req.params.id, recipient: req.user._id }, { read: true }, { new: true }); // ownership enforced in the query
  if (!n) throw new HttpError(404, 'Notification not found');
  ok(res, n);
});
exports.markAll = asyncH(async (req, res) => { await Notification.updateMany({ recipient: req.user._id, read: false }, { read: true }); ok(res, { unread: 0 }); });
