const mongoose = require('mongoose');
const { FocusSession, Task } = require('../models');
const { HttpError, asyncH, ok } = require('../utils/http');
const { loadProject } = require('../services/access');
const { evaluate } = require('../services/achievements');
const { dayKey } = require('../utils/dates');
const config = require('../config');

const elapsedMs = (s, now = Date.now()) => now - s.startedAt.getTime() - s.pausedMs - (s.pausedAt ? now - s.pausedAt.getTime() : 0);
const view = (s) => ({ ...s.toObject(), serverNow: Date.now(), elapsedMs: Math.max(0, elapsedMs(s)) });

// Sessions that finished long ago without the client confirming completion are marked abandoned, never completed.
async function settleStale(userId) {
  const running = await FocusSession.find({ user: userId, status: 'running' });
  for (const s of running) {
    if (!s.pausedAt && elapsedMs(s) > s.plannedSeconds * 1000 + config.focus.graceSeconds * 1000) { s.status = 'abandoned'; s.endedAt = new Date(); await s.save(); }
  }
}
exports.start = asyncH(async (req, res) => {
  const type = req.body.type || 'focus';
  if (req.body.task) {
    if (!mongoose.isValidObjectId(req.body.task)) throw new HttpError(422, 'Invalid task');
    const t = await Task.findById(req.body.task).select('project');
    if (!t) throw new HttpError(404, 'Task not found');
    await loadProject(req.user._id, t.project);
  }
  await FocusSession.updateMany({ user: req.user._id, status: 'running' }, { status: 'abandoned', endedAt: new Date() });
  const s = await FocusSession.create({ user: req.user._id, task: req.body.task || null, type, plannedSeconds: config.focus[type] });
  ok(res, view(s), 201);
});
exports.active = asyncH(async (req, res) => {
  await settleStale(req.user._id);
  const s = await FocusSession.findOne({ user: req.user._id, status: 'running' }).populate('task', 'title');
  ok(res, s ? view(s) : null);
});
async function mine(req) {
  if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Session not found');
  const s = await FocusSession.findOne({ _id: req.params.id, user: req.user._id });
  if (!s) throw new HttpError(404, 'Session not found');
  if (s.status !== 'running') throw new HttpError(409, `Session already ${s.status}`);
  return s;
}
exports.pause = asyncH(async (req, res) => { const s = await mine(req); if (!s.pausedAt) { s.pausedAt = new Date(); await s.save(); } ok(res, view(s)); });
exports.resume = asyncH(async (req, res) => { const s = await mine(req); if (s.pausedAt) { s.pausedMs += Date.now() - s.pausedAt.getTime(); s.pausedAt = undefined; await s.save(); } ok(res, view(s)); });
exports.abandon = asyncH(async (req, res) => { const s = await mine(req); s.status = 'abandoned'; s.endedAt = new Date(); await s.save(); ok(res, view(s)); });
exports.complete = asyncH(async (req, res) => {
  const s = await mine(req);
  if (s.pausedAt) throw new HttpError(400, 'Resume the session before completing it');
  if (elapsedMs(s) < s.plannedSeconds * 1000 - 2000) throw new HttpError(400, 'The session has not finished yet');
  s.status = 'completed'; s.endedAt = new Date();
  await s.save();
  const badges = await evaluate(req.user._id);
  ok(res, { ...view(s), newBadges: badges });
});
exports.history = asyncH(async (req, res) => {
  const sessions = await FocusSession.find({ user: req.user._id, status: { $ne: 'running' } }).sort({ startedAt: -1 }).limit(30).populate('task', 'title').lean();
  const all = await FocusSession.find({ user: req.user._id, status: 'completed', type: 'focus' }).select('endedAt plannedSeconds').lean();
  const today = dayKey(new Date()), byDay = {};
  all.forEach((s) => { const k = dayKey(s.endedAt); byDay[k] = (byDay[k] || 0) + s.plannedSeconds / 60; });
  const days = [...Array(7)].map((_, i) => { const k = dayKey(Date.now() - (6 - i) * 864e5); return { day: k, minutes: Math.round(byDay[k] || 0) }; });
  ok(res, { sessions, stats: { todaySessions: all.filter((s) => dayKey(s.endedAt) === today).length, todayMinutes: Math.round(byDay[today] || 0), totalSessions: all.length, totalMinutes: Math.round(Object.values(byDay).reduce((a, b) => a + b, 0)) }, days });
});
