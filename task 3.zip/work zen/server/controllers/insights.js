const { Project, Task, Activity, Notification, FocusSession, Achievement } = require('../models');
const { HttpError, asyncH, ok } = require('../utils/http');
const { accessibleProjectIds } = require('../services/access');
const { computeHealth } = require('../services/health');
const { rank, scoreTask } = require('../services/priority');
const { BADGES, userStats } = require('../services/achievements');
const { daysUntil, dayKey } = require('../utils/dates');

const isOpen = (t) => t.status !== 'Completed';
const isOverdue = (t) => isOpen(t) && t.dueDate && daysUntil(t.dueDate) < 0;
const withDays = (t) => ({ ...t, daysLeft: t.dueDate ? daysUntil(t.dueDate) : null });
const pop = (q) => q.populate('project', 'name').populate('assignee', 'name avatarColor').lean();

exports.dashboard = asyncH(async (req, res) => {
  const ids = await accessibleProjectIds(req.user._id);
  const [projects, tasks, activity, notifs, unread, focusAll] = await Promise.all([
    Project.find({ _id: { $in: ids } }).select('name status startDate deadline').lean(),
    pop(Task.find({ project: { $in: ids } })),
    Activity.find({ project: { $in: ids } }).sort({ createdAt: -1 }).limit(8).populate('user', 'name avatarColor').populate('project', 'name').lean(),
    Notification.find({ recipient: req.user._id }).sort({ createdAt: -1 }).limit(5).lean(),
    Notification.countDocuments({ recipient: req.user._id, read: false }),
    FocusSession.find({ user: req.user._id, status: 'completed', type: 'focus' }).select('endedAt plannedSeconds').lean(),
  ]);
  const done = tasks.filter((t) => !isOpen(t)), mineOpen = tasks.filter((t) => isOpen(t) && String(t.assignee?._id) === String(req.user._id));
  const days = [...Array(7)].map((_, i) => { const k = dayKey(Date.now() - (6 - i) * 864e5); return { day: k, completed: done.filter((t) => t.completedAt && dayKey(t.completedAt) === k).length }; });
  const today = dayKey(new Date()), stats = await userStats(req.user._id);
  ok(res, {
    totals: { projects: projects.length, activeProjects: projects.filter((p) => p.status === 'Active').length, tasks: tasks.length, completed: done.length, pending: tasks.length - done.length, overdue: tasks.filter(isOverdue).length, completionPct: tasks.length ? Math.round((done.length / tasks.length) * 100) : 0 },
    upcoming: tasks.filter((t) => isOpen(t) && t.dueDate && daysUntil(t.dueDate) >= 0 && daysUntil(t.dueDate) <= 7).sort((a, b) => a.dueDate - b.dueDate).slice(0, 6).map(withDays),
    doFirst: rank(mineOpen).filter((t) => t.rec.category === 'Do First').slice(0, 3),
    activity, notifications: notifs, unread, productivity: { days, completedThisWeek: stats.weekly, streak: stats.streak },
    focus: { todaySessions: focusAll.filter((s) => dayKey(s.endedAt) === today).length, todayMinutes: Math.round(focusAll.filter((s) => dayKey(s.endedAt) === today).reduce((a, s) => a + s.plannedSeconds / 60, 0)), totalSessions: focusAll.length },
  });
});

async function scope(req) {
  const ids = await accessibleProjectIds(req.user._id);
  let use = ids;
  if (req.query.project) { if (!ids.map(String).includes(String(req.query.project))) throw new HttpError(404, 'Project not found'); use = [req.query.project]; }
  return use;
}
exports.teamPulse = asyncH(async (req, res) => {
  const use = await scope(req), days = [7, 14, 30, 90].includes(+req.query.days) ? +req.query.days : 7;
  const since = new Date(Date.now() - days * 864e5);
  const [projects, tasks, activity] = await Promise.all([
    Project.find({ _id: { $in: use } }).lean(), pop(Task.find({ project: { $in: use } })),
    Activity.find({ project: { $in: use }, createdAt: { $gte: since } }).sort({ createdAt: -1 }).limit(15).populate('user', 'name avatarColor').populate('project', 'name').lean(),
  ]);
  const members = new Map();
  tasks.forEach((t) => { if (!t.assignee) return; const k = String(t.assignee._id); if (!members.has(k)) members.set(k, { user: t.assignee, open: 0, inProgress: 0, completedInPeriod: 0, overdue: 0 });
    const m = members.get(k); if (isOpen(t)) m.open++; if (t.status === 'In Progress') m.inProgress++; if (!isOpen(t) && t.completedAt >= since) m.completedInPeriod++; if (isOverdue(t)) m.overdue++; });
  ok(res, {
    days, summary: { completedInPeriod: tasks.filter((t) => !isOpen(t) && t.completedAt >= since).length, inProgress: tasks.filter((t) => t.status === 'In Progress').length, pending: tasks.filter((t) => t.status === 'To Do').length, inReview: tasks.filter((t) => t.status === 'In Review').length, overdue: tasks.filter(isOverdue).length },
    projects: projects.map((p) => { const h = computeHealth(p, tasks.filter((t) => String(t.project._id) === String(p._id))); return { _id: p._id, name: p.name, progress: h.progress, health: h.score, status: h.status }; }),
    workload: [...members.values()].sort((a, b) => a.user.name.localeCompare(b.user.name)), // alphabetical on purpose: indicators, not a ranking
    activity, note: 'These figures are informational indicators of activity, not measures of individual performance.',
  });
});
exports.deadlines = asyncH(async (req, res) => {
  const use = await scope(req);
  const f = { project: { $in: use } };
  if (req.query.assignee) f.assignee = req.query.assignee === 'me' ? req.user._id : req.query.assignee;
  if (req.query.priority) f.priority = req.query.priority;
  const tasks = (await pop(Task.find(f))).map(withDays);
  const open = tasks.filter((t) => isOpen(t) && t.dueDate), by = (fn) => open.filter(fn).sort((a, b) => a.dueDate - b.dueDate);
  const projects = await Project.find({ _id: { $in: use }, status: { $ne: 'Completed' }, deadline: { $ne: null } }).select('name deadline').lean();
  ok(res, {
    overdue: by((t) => t.daysLeft < 0), today: by((t) => t.daysLeft === 0), soon: by((t) => t.daysLeft >= 1 && t.daysLeft <= 3),
    upcomingProjects: projects.map((p) => ({ ...p, daysLeft: daysUntil(p.deadline) })).sort((a, b) => a.daysLeft - b.daysLeft),
    completed: tasks.filter((t) => !isOpen(t)).sort((a, b) => b.completedAt - a.completedAt).slice(0, 10),
  });
});
exports.achievements = asyncH(async (req, res) => {
  const [earned, stats] = await Promise.all([Achievement.find({ user: req.user._id }).lean(), userStats(req.user._id)]);
  const map = new Map(earned.map((e) => [e.badge, e.awardedAt]));
  ok(res, { badges: Object.entries(BADGES).map(([key, b]) => ({ key, ...b, earned: map.has(key), awardedAt: map.get(key) || null })), streak: stats.streak, stats: { today: stats.todayCompleted, week: stats.weekly, focusSessions: stats.focusSessions, completed: stats.completed } });
});
