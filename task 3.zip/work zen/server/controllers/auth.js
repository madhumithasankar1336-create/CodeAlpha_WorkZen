const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), crypto = require('crypto');
const { User } = require('../models');
const config = require('../config');
const { HttpError, asyncH, ok } = require('../utils/http');

const base = { sameSite: 'lax', secure: config.env === 'production', maxAge: 7 * 864e5, path: '/' };
function setSession(res, user) {
  res.cookie('wz_token', jwt.sign({ id: user.id }, config.jwtSecret, { expiresIn: '7d' }), { ...base, httpOnly: true });
  res.cookie('wz_csrf', crypto.randomBytes(24).toString('hex'), { ...base, httpOnly: false });
}
const COLORS = ['#22D3EE', '#8B5CF6', '#F59E0B', '#10B981', '#EC4899', '#3B82F6'];

exports.register = asyncH(async (req, res) => {
  const { name, email, password } = req.body;
  if (await User.exists({ email })) throw new HttpError(409, 'An account with this email already exists');
  const user = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12), avatarColor: COLORS[Math.floor(Math.random() * COLORS.length)] });
  setSession(res, user);
  ok(res, user, 201);
});
exports.login = asyncH(async (req, res) => {
  const user = await User.findOne({ email: req.body.email }).select('+passwordHash');
  const valid = user && (await bcrypt.compare(req.body.password, user.passwordHash));
  if (!valid) throw new HttpError(401, 'Invalid email or password');
  setSession(res, user);
  ok(res, user);
});
exports.logout = (req, res) => { res.clearCookie('wz_token', { path: '/' }); res.clearCookie('wz_csrf', { path: '/' }); ok(res, { loggedOut: true }); };
exports.me = (req, res) => ok(res, req.user);
