const { Project, Task, Comment, Activity, Notification, User } = require('../models');
const { HttpError, asyncH, ok, escapeRegex } = require('../utils/http');
const { loadProject, isManager, memberRole } = require('../services/access');
const { computeHealth } = require('../services/health');
const { log } = require('../services/activity');
const { notify } = require('../services/notify');
const events = require('../services/events');
const { toDate, daysUntil } = require('../utils/dates');
const config = require('../config');

const MEMBER_FIELDS = 'name email avatarColor';
const present = (p, tasks = []) => ({ ...p.toObject(), health: computeHealth(p, tasks) });

exports.list = asyncH(async (req, res) => {
  const q = { 'members.user': req.user._id };
  if (req.query.status) q.status = req.query.status;
  if (req.query.q) q.name = new RegExp(escapeRegex(req.query.q), 'i');
  const projects = await Project.find(q).populate('members.user', MEMBER_FIELDS).populate('owner', 'name').sort({ updatedAt: -1 });
  const tasks = await Task.find({ project: { $in: projects.map((p) => p._id) } }).select('project status dueDate').lean();
  ok(res, projects.map((p) => {
    const mine = tasks.filter((t) => String(t.project) === String(p._id));
    return { ...present(p, mine), myRole: memberRole(p, req.user._id) };
  }));
});
exports.create = asyncH(async (req, res) => {
  const b = req.body;
  const startDate = toDate(b.startDate), deadline = toDate(b.deadline);
  if (startDate && deadline && deadline < startDate) throw new HttpError(422, 'Deadline cannot be before the start date');
  const p = await Project.create({ name: b.name, description: b.description || '', owner: req.user._id, members: [{ user: req.user._id, role: 'owner' }], startDate, deadline, status: b.status || 'Active' });
  await log(p._id, req.user, `created project "${p.name}"`);
  events.joinUser(req.user._id, p._id);
  ok(res, p, 201);
});
exports.get = asyncH(async (req, res) => {
  const { project, role } = await loadProject(req.user._id, req.params.id);
  await project.populate([{ path: 'members.user', select: MEMBER_FIELDS }, { path: 'owner', select: 'name' }]);
  const tasks = await Task.find({ project: project._id }).select('status dueDate').lean();
  ok(res, { ...present(project, tasks), myRole: role });
});
exports.update = asyncH(async (req, res) => {
  const { project, role } = await loadProject(req.user._id, req.params.id);
  if (!isManager(role)) throw new HttpError(403, 'Only owners and admins can edit project details');
  const b = req.body;
  ['name', 'description', 'status'].forEach((k) => { if (b[k] !== undefined) project[k] = b[k]; });
  if (b.startDate !== undefined) project.startDate = toDate(b.startDate);
  if (b.deadline !== undefined) project.deadline = toDate(b.deadline);
  if (project.startDate && project.deadline && project.deadline < project.startDate) throw new HttpError(422, 'Deadline cannot be before the start date');
  await project.save();
  await log(project._id, req.user, 'updated project details');
  events.toProject(project._id, 'project:updated', { projectId: String(project._id) });
  ok(res, project);
});
exports.remove = asyncH(async (req, res) => {
  const { project, role } = await loadProject(req.user._id, req.params.id);
  if (role !== 'owner') throw new HttpError(403, 'Only the project owner can delete a project');
  events.toProject(project._id, 'project:deleted', { projectId: String(project._id) });
  await Promise.all([Task.deleteMany({ project: project._id }), Comment.deleteMany({ project: project._id }), Activity.deleteMany({ project: project._id }), Notification.deleteMany({ project: project._id })]);
  await project.deleteOne();
  ok(res, { deleted: true });
});
exports.addMember = asyncH(async (req, res) => {
  const { project, role } = await loadProject(req.user._id, req.params.id);
  if (!isManager(role)) throw new HttpError(403, 'Only owners and admins can add members');
  const wanted = req.body.role || 'member';
  if (wanted === 'admin' && role !== 'owner') throw new HttpError(403, 'Only the owner can add admins');
  const user = await User.findOne({ email: req.body.email });
  if (!user) throw new HttpError(404, 'No registered user with that email');
  if (memberRole(project, user._id)) throw new HttpError(409, 'That user is already a member');
  project.members.push({ user: user._id, role: wanted });
  await project.save();
  await log(project._id, req.user, `added ${user.name} as ${wanted}`);
  events.joinUser(user._id, project._id);
  await notify({ recipient: user._id, actor: req.user._id, type: 'project_invite', message: `${req.user.name} added you to "${project.name}" as ${wanted}`, project: project._id, key: `invite:${project._id}:${user._id}:${Date.now()}` });
  events.toProject(project._id, 'project:updated', { projectId: String(project._id) });
  ok(res, { added: true }, 201);
});
exports.setRole = asyncH(async (req, res) => {
  const { project, role } = await loadProject(req.user._id, req.params.id);
  if (role !== 'owner') throw new HttpError(403, 'Only the owner can change roles');
  const m = project.members.find((x) => String(x.user) === req.params.userId);
  if (!m) throw new HttpError(404, 'Member not found');
  if (m.role === 'owner') throw new HttpError(400, 'The owner role cannot be changed');
  m.role = req.body.role;
  await project.save();
  await log(project._id, req.user, `changed a member role to ${m.role}`);
  ok(res, { updated: true });
});
exports.removeMember = asyncH(async (req, res) => {
  const { project, role } = await loadProject(req.user._id, req.params.id);
  const target = project.members.find((x) => String(x.user) === req.params.userId);
  if (!target) throw new HttpError(404, 'Member not found');
  const self = String(req.user._id) === req.params.userId;
  if (target.role === 'owner') throw new HttpError(400, 'The owner cannot be removed');
  if (!self && !(role === 'owner' || (role === 'admin' && target.role === 'member'))) throw new HttpError(403, 'You do not have permission to remove this member');
  project.members = project.members.filter((x) => String(x.user) !== req.params.userId);
  await project.save();
  await Task.updateMany({ project: project._id, assignee: req.params.userId }, { assignee: null });
  await log(project._id, req.user, self ? 'left the project' : 'removed a member');
  events.leaveUser(req.params.userId, project._id);
  events.toProject(project._id, 'project:updated', { projectId: String(project._id) });
  ok(res, { removed: true });
});
exports.activity = asyncH(async (req, res) => {
  const { project } = await loadProject(req.user._id, req.params.id);
  const items = await Activity.find({ project: project._id }).sort({ createdAt: -1 }).limit(100).populate('user', 'name avatarColor').populate('task', 'title').lean();
  ok(res, items);
});
// Workload per member with configurable thresholds (env defaults, overridable per request).
exports.workload = asyncH(async (req, res) => {
  const { project } = await loadProject(req.user._id, req.params.id);
  await project.populate('members.user', MEMBER_FIELDS);
  const maxOpen = +req.query.maxOpen || config.workload.maxOpen, maxOverdue = +req.query.maxOverdue || config.workload.maxOverdue;
  const tasks = await Task.find({ project: project._id }).select('assignee status dueDate').lean();
  const rows = project.members.map((m) => {
    const mine = tasks.filter((t) => String(t.assignee) === String(m.user._id)), open = mine.filter((t) => t.status !== 'Completed');
    const overdue = open.filter((t) => t.dueDate && daysUntil(t.dueDate) < 0).length;
    const upcoming = open.filter((t) => t.dueDate && daysUntil(t.dueDate) >= 0 && daysUntil(t.dueDate) <= 3).length;
    const reasons = [];
    if (open.length >= maxOpen) reasons.push(`${open.length} open tasks (limit ${maxOpen})`);
    if (overdue >= maxOverdue) reasons.push(`${overdue} overdue tasks (limit ${maxOverdue})`);
    return { user: m.user, role: m.role, assigned: mine.length, inProgress: mine.filter((t) => t.status === 'In Progress').length, completed: mine.length - open.length, open: open.length, overdue, upcoming, high: reasons.length > 0, reasons };
  });
  ok(res, { rules: { maxOpen, maxOverdue }, members: rows, unassigned: tasks.filter((t) => !t.assignee && t.status !== 'Completed').length });
});
