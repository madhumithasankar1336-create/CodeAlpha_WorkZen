const { User, Task, FocusSession, Achievement, Project } = require('../models');
const { asyncH, ok, HttpError } = require('../utils/http');
const { BADGES, userStats } = require('../services/achievements');
const { accessibleProjectIds } = require('../services/access');

// Only name and avatarColor are editable. Roles/ids/email cannot be changed here.
exports.update = asyncH(async (req, res) => {
  if (req.body.name !== undefined) req.user.name = req.body.name;
  if (req.body.avatarColor !== undefined) req.user.avatarColor = req.body.avatarColor;
  await req.user.save();
  ok(res, req.user);
});
exports.profile = asyncH(async (req, res) => {
  const id = req.user._id;
  const [stats, assigned, sessions, badges, minutes] = await Promise.all([
    userStats(id), Task.countDocuments({ assignee: id }), FocusSession.countDocuments({ user: id, status: 'completed', type: 'focus' }),
    Achievement.find({ user: id }).lean(), FocusSession.find({ user: id, status: 'completed', type: 'focus' }).select('plannedSeconds').lean(),
  ]);
  ok(res, {
    user: req.user,
    tasks: { assigned, completed: stats.completed, completedThisWeek: stats.weekly },
    focus: { sessions, minutes: Math.round(minutes.reduce((s, m) => s + m.plannedSeconds, 0) / 60) },
    streak: stats.streak,
    badges: badges.map((b) => ({ key: b.badge, ...BADGES[b.badge], awardedAt: b.awardedAt })).filter((b) => b.name),
  });
});
// Users the caller shares at least one project with (optionally narrowed to one project they belong to).
exports.team = asyncH(async (req, res) => {
  const ids = await accessibleProjectIds(req.user._id);
  const q = { _id: { $in: ids } };
  if (req.query.project) { if (!ids.map(String).includes(String(req.query.project))) throw new HttpError(404, 'Project not found'); q._id = req.query.project; }
  const projects = await Project.find(q).populate('members.user', 'name email avatarColor').lean();
  const map = new Map();
  projects.forEach((p) => p.members.forEach((m) => m.user && map.set(String(m.user._id), m.user)));
  ok(res, [...map.values()]);
});
