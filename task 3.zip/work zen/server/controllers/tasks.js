const mongoose = require('mongoose');
const { Task, Comment, Activity, Project } = require('../models');
const { HttpError, asyncH, ok, escapeRegex } = require('../utils/http');
const { loadProject, isManager, memberRole, accessibleProjectIds } = require('../services/access');
const { log } = require('../services/activity');
const { notify } = require('../services/notify');
const { rank } = require('../services/priority');
const { evaluate } = require('../services/achievements');
const events = require('../services/events');
const { toDate, daysUntil } = require('../utils/dates');

const populate = (q) => q.populate('project', 'name').populate('assignee', 'name avatarColor').populate('creator', 'name');
const plain = (t) => { const o = t.toObject ? t.toObject() : t; o.overdue = o.status !== 'Completed' && !!o.dueDate && daysUntil(o.dueDate) < 0; return o; };

async function buildFilter(req) {
  const ids = await accessibleProjectIds(req.user._id);
  const f = { project: { $in: ids } };
  const { project, assignee, status, priority, q, mine } = req.query;
  if (project) { if (!ids.map(String).includes(String(project))) throw new HttpError(404, 'Project not found'); f.project = project; }
  if (mine === '1') f.assignee = req.user._id; else if (assignee === 'unassigned') f.assignee = null; else if (assignee && mongoose.isValidObjectId(assignee)) f.assignee = assignee;
  if (status) f.status = status;
  if (priority) f.priority = priority;
  if (q) f.title = new RegExp(escapeRegex(q), 'i');
  return f;
}
exports.list = asyncH(async (req, res) => {
  const sort = req.query.sort === 'due' ? { dueDate: 1 } : { createdAt: -1 };
  ok(res, (await populate(Task.find(await buildFilter(req)).sort(sort).limit(500))).map(plain));
});
exports.prioritized = asyncH(async (req, res) => {
  const tasks = (await populate(Task.find(await buildFilter(req)).limit(500))).map(plain);
  ok(res, rank(tasks, req.query.sort));
});
exports.create = asyncH(async (req, res) => {
  const b = req.body;
  const { project } = await loadProject(req.user._id, b.project);
  if (b.assignee && !memberRole(project, b.assignee)) throw new HttpError(422, 'Assignee must be a member of the project');
  const startDate = toDate(b.startDate), dueDate = toDate(b.dueDate);
  if (startDate && dueDate && dueDate < startDate) throw new HttpError(422, 'Due date cannot be before the start date');
  const status = b.status || 'To Do';
  const task = await Task.create({ title: b.title, description: b.description || '', project: project._id, creator: req.user._id, assignee: b.assignee || null, status, priority: b.priority || 'Medium', startDate, dueDate, completedAt: status === 'Completed' ? new Date() : null });
  await log(project._id, req.user, `created task "${task.title}"`, task._id);
  if (task.assignee) await notify({ recipient: task.assignee, actor: req.user._id, type: 'task_assigned', message: `${req.user.name} assigned you "${task.title}"`, project: project._id, task: task._id, key: `assign:${task._id}:${task.assignee}:${task.createdAt.getTime()}` });
  events.toProject(project._id, 'task:created', { projectId: String(project._id), taskId: String(task._id) });
  ok(res, plain(await populate(Task.findById(task._id))), 201);
});
async function loadTask(req) {
  if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Task not found');
  const task = await Task.findById(req.params.id);
  if (!task) throw new HttpError(404, 'Task not found');
  const { project, role } = await loadProject(req.user._id, task.project);
  const me = String(req.user._id);
  const canEdit = isManager(role) || String(task.creator) === me || String(task.assignee) === me;
  return { task, project, role, canEdit, canManage: isManager(role) };
}
exports.get = asyncH(async (req, res) => {
  const { task, canEdit, canManage, role } = await loadTask(req);
  const [t, comments, activity] = await Promise.all([
    populate(Task.findById(task._id)), Comment.find({ task: task._id }).sort({ createdAt: 1 }).populate('author', 'name avatarColor').lean(),
    Activity.find({ task: task._id }).sort({ createdAt: 1 }).populate('user', 'name avatarColor').lean(),
  ]);
  ok(res, { task: plain(t), comments, activity, canEdit, canManage, role });
});
exports.update = asyncH(async (req, res) => {
  const { task, project, canEdit } = await loadTask(req);
  if (!canEdit) throw new HttpError(403, 'You do not have permission to edit this task');
  const b = req.body;
  ['title', 'description', 'priority'].forEach((k) => { if (b[k] !== undefined) task[k] = b[k]; }); // assignee/project/creator are NOT editable here
  if (b.startDate !== undefined) task.startDate = toDate(b.startDate);
  if (b.dueDate !== undefined) task.dueDate = toDate(b.dueDate);
  if (task.startDate && task.dueDate && task.dueDate < task.startDate) throw new HttpError(422, 'Due date cannot be before the start date');
  if (b.status !== undefined && b.status !== task.status) await applyStatus(task, b.status, req.user, project);
  await task.save();
  await log(project._id, req.user, `edited task "${task.title}"`, task._id);
  if (task.assignee) await notify({ recipient: task.assignee, actor: req.user._id, type: 'task_updated', message: `${req.user.name} updated "${task.title}"`, project: project._id, task: task._id, key: `upd:${task._id}:${task.assignee}:${task.updatedAt.getTime()}` });
  events.toProject(project._id, 'task:updated', { projectId: String(project._id), taskId: String(task._id) });
  ok(res, plain(await populate(Task.findById(task._id))));
});
async function applyStatus(task, status, user, project) {
  const from = task.status;
  task.status = status;
  task.completedAt = status === 'Completed' ? new Date() : null;
  await log(project._id, user, `moved "${task.title}" from ${from} to ${status}`, task._id);
}
exports.setStatus = asyncH(async (req, res) => {
  const { task, project, canEdit } = await loadTask(req);
  if (!canEdit) throw new HttpError(403, 'You do not have permission to change this task');
  if (task.status !== req.body.status) {
    await applyStatus(task, req.body.status, req.user, project);
    await task.save();
    const recipients = new Set([String(task.assignee || ''), String(task.creator)].filter(Boolean));
    for (const r of recipients) await notify({ recipient: r, actor: req.user._id, type: 'task_updated', message: `${req.user.name} moved "${task.title}" to ${task.status}`, project: project._id, task: task._id, key: `status:${task._id}:${r}:${task.updatedAt.getTime()}` });
    if (task.status === 'Completed' && task.assignee) await evaluate(task.assignee);
    events.toProject(project._id, 'task:updated', { projectId: String(project._id), taskId: String(task._id), status: task.status });
  }
  ok(res, plain(await populate(Task.findById(task._id))));
});
// Reassignment is manager-only and needs explicit confirmation from the client; nothing reassigns automatically.
exports.assign = asyncH(async (req, res) => {
  const { task, project, canManage } = await loadTask(req);
  if (!canManage) throw new HttpError(403, 'Only project owners and admins can reassign tasks');
  if (req.body.confirm !== true) throw new HttpError(400, 'Reassignment must be confirmed (confirm: true)');
  const to = req.body.assignee || null;
  if (to && !memberRole(project, to)) throw new HttpError(422, 'Assignee must be a member of the project');
  if (String(task.assignee || '') === String(to || '')) return ok(res, plain(await populate(Task.findById(task._id))));
  task.assignee = to;
  await task.save();
  await log(project._id, req.user, to ? `reassigned "${task.title}"` : `unassigned "${task.title}"`, task._id);
  if (to) await notify({ recipient: to, actor: req.user._id, type: 'task_assigned', message: `${req.user.name} assigned you "${task.title}"`, project: project._id, task: task._id, key: `assign:${task._id}:${to}:${task.updatedAt.getTime()}` });
  events.toProject(project._id, 'task:updated', { projectId: String(project._id), taskId: String(task._id) });
  ok(res, plain(await populate(Task.findById(task._id))));
});
exports.remove = asyncH(async (req, res) => {
  const { task, project, role } = await loadTask(req);
  if (!(isManager(role) || String(task.creator) === String(req.user._id))) throw new HttpError(403, 'Only the creator or a project admin can delete this task');
  await Promise.all([Comment.deleteMany({ task: task._id }), task.deleteOne()]);
  await log(project._id, req.user, `deleted task "${task.title}"`);
  events.toProject(project._id, 'task:updated', { projectId: String(project._id), taskId: String(task._id), deleted: true });
  ok(res, { deleted: true });
});
exports.addComment = asyncH(async (req, res) => {
  const { task, project } = await loadTask(req);
  const c = await Comment.create({ task: task._id, project: project._id, author: req.user._id, text: req.body.text });
  await log(project._id, req.user, `commented on "${task.title}"`, task._id);
  for (const r of new Set([String(task.assignee || ''), String(task.creator)].filter(Boolean)))
    await notify({ recipient: r, actor: req.user._id, type: 'comment', message: `${req.user.name} commented on "${task.title}"`, project: project._id, task: task._id, key: `comment:${c._id}:${r}` });
  const out = await c.populate('author', 'name avatarColor');
  events.toProject(project._id, 'comment:new', { projectId: String(project._id), taskId: String(task._id), comment: out });
  await evaluate(req.user._id);
  ok(res, out, 201);
});
exports.removeComment = asyncH(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Comment not found');
  const c = await Comment.findById(req.params.id);
  if (!c) throw new HttpError(404, 'Comment not found');
  const { role } = await loadProject(req.user._id, c.project);
  if (String(c.author) !== String(req.user._id) && !isManager(role)) throw new HttpError(403, 'You can only delete your own comments');
  await c.deleteOne();
  events.toProject(c.project, 'comment:deleted', { projectId: String(c.project), taskId: String(c.task) });
  ok(res, { deleted: true });
});
