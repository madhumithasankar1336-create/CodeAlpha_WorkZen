const { Server } = require('socket.io');
const cookie = require('cookie');
const jwt = require('jsonwebtoken');
const config = require('../config');
const { User, Project } = require('../models');
const events = require('../services/events');

// Authenticated Socket.IO: JWT from the HttpOnly cookie, rooms joined only for projects the user belongs to.
module.exports = function attachSocket(httpServer) {
  const io = new Server(httpServer, { cors: { origin: config.clientUrl, credentials: true } });
  io.use(async (socket, next) => {
    try {
      const token = cookie.parse(socket.handshake.headers.cookie || '').wz_token;
      if (!token) return next(new Error('unauthorized'));
      const user = await User.findById(jwt.verify(token, config.jwtSecret).id);
      if (!user) return next(new Error('unauthorized'));
      socket.user = user;
      next();
    } catch { next(new Error('unauthorized')); }
  });
  io.on('connection', async (socket) => {
    socket.join(`user:${socket.user.id}`);
    const projects = await Project.find({ 'members.user': socket.user._id }).select('_id');
    projects.forEach((p) => socket.join(`project:${p._id}`));
    socket.on('project:join', async (projectId, ack) => { // server re-checks membership; clients cannot self-subscribe
      const ok = typeof projectId === 'string' && /^[a-f\d]{24}$/i.test(projectId) && !!(await Project.exists({ _id: projectId, 'members.user': socket.user._id }));
      if (ok) socket.join(`project:${projectId}`);
      if (typeof ack === 'function') ack({ ok });
    });
  });
  events.setIo(io);
  return io;
};
