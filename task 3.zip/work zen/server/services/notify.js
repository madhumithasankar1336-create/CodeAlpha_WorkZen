const { Notification } = require('../models');
const events = require('./events');
// Creates a notification unless it targets the actor or the dedupeKey already exists. Emits unread count in real time.
async function notify({ recipient, actor, type, message, project, task, key }) {
  if (!recipient || (actor && String(recipient) === String(actor))) return null;
  try {
    const n = await Notification.create({ recipient, type, message, project, task, dedupeKey: key || undefined });
    const unread = await Notification.countDocuments({ recipient, read: false });
    events.toUser(recipient, 'notification:new', { notification: n, unread });
    return n;
  } catch (e) { if (e.code === 11000) return null; throw e; }
}
module.exports = { notify };
