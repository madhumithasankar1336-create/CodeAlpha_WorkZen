const mongoose = require('mongoose');
const { Project } = require('../models');
const { HttpError } = require('../utils/http');

const isManager = (role) => role === 'owner' || role === 'admin';
const memberRole = (project, userId) => { const m = project.members.find((x) => String(x.user._id || x.user) === String(userId)); return m ? m.role : null; };

// Returns { project, role } or throws. Non-members get 404 so project existence is not leaked.
async function loadProject(userId, projectId) {
  if (!mongoose.isValidObjectId(projectId)) throw new HttpError(404, 'Project not found');
  const project = await Project.findById(projectId);
  const role = project && memberRole(project, userId);
  if (!role) throw new HttpError(404, 'Project not found');
  return { project, role };
}
const accessibleProjectIds = (userId) => Project.find({ 'members.user': userId }).distinct('_id');
module.exports = { isManager, memberRole, loadProject, accessibleProjectIds };
