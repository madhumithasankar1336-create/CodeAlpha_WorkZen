const { Task, FocusSession, Comment, Achievement } = require('../models');
const { dayKey, addDaysKey } = require('../utils/dates');
const { notify } = require('./notify');

const BADGES = {
  first_task: { name: 'First Task Completed', icon: '🏁', criteria: 'Complete one task assigned to you (it must have existed for at least 1 minute).' },
  focus_starter: { name: 'Focus Starter', icon: '🎯', criteria: 'Complete one full 25-minute focus session.' },
  deadline_champion: { name: 'Deadline Champion', icon: '🏆', criteria: 'Complete 5 tasks on or before their due date.' },
  team_collaborator: { name: 'Team Collaborator', icon: '🤝', criteria: 'Post 3 comments on tasks created by teammates.' },
  weekly_achiever: { name: 'Weekly Achiever', icon: '⭐', criteria: 'Complete 5 tasks within the last 7 days.' },
};

// Anti-gaming: only count tasks assigned to the user, alive >= 60s before completion, and de-duplicate identical titles per project.
async function countedCompletions(userId) {
  const tasks = await Task.find({ assignee: userId, status: 'Completed', completedAt: { $ne: null } }).select('title project createdAt completedAt dueDate').lean();
  const seen = new Set();
  return tasks.filter((t) => {
    if (t.completedAt - t.createdAt < 60000) return false;
    const k = `${t.project}:${t.title.trim().toLowerCase()}`;
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
}
function streakFrom(keys, today = dayKey(new Date())) {
  const set = new Set(keys);
  let cur = 0, day = set.has(today) ? today : addDaysKey(today, -1);
  while (set.has(day)) { cur++; day = addDaysKey(day, -1); }
  const sorted = [...set].sort();
  let longest = 0, run = 0, prev = null;
  for (const k of sorted) { run = prev && addDaysKey(prev, 1) === k ? run + 1 : 1; longest = Math.max(longest, run); prev = k; }
  return { current: cur, longest };
}
async function userStats(userId) {
  const done = await countedCompletions(userId);
  const sessions = await FocusSession.find({ user: userId, status: 'completed', type: 'focus' }).select('endedAt').lean();
  const weekAgo = Date.now() - 7 * 864e5;
  const mine = await Comment.find({ author: userId }).populate('task', 'creator').limit(200).lean();
  const days = [...done.map((t) => dayKey(t.completedAt)), ...sessions.map((s) => dayKey(s.endedAt))];
  const today = dayKey(new Date());
  return {
    completed: done.length,
    onTime: done.filter((t) => t.dueDate && dayKey(t.completedAt) <= dayKey(t.dueDate)).length,
    weekly: done.filter((t) => t.completedAt.getTime() >= weekAgo).length,
    todayCompleted: done.filter((t) => dayKey(t.completedAt) === today).length,
    focusSessions: sessions.length,
    teamComments: mine.filter((c) => c.task && String(c.task.creator) !== String(userId)).length,
    streak: streakFrom(days),
  };
}
const rules = { first_task: (s) => s.completed >= 1, focus_starter: (s) => s.focusSessions >= 1, deadline_champion: (s) => s.onTime >= 5, team_collaborator: (s) => s.teamComments >= 3, weekly_achiever: (s) => s.weekly >= 5 };

async function evaluate(userId) {
  const stats = await userStats(userId), awarded = [];
  for (const [key, test] of Object.entries(rules)) {
    if (!test(stats)) continue;
    const r = await Achievement.updateOne({ user: userId, badge: key }, { $setOnInsert: { awardedAt: new Date() } }, { upsert: true });
    if (r.upsertedCount) { awarded.push(key); await notify({ recipient: userId, type: 'badge', message: `You earned the "${BADGES[key].name}" badge!`, key: `badge:${key}:${userId}` }); }
  }
  return awarded;
}
module.exports = { BADGES, evaluate, userStats, streakFrom };
