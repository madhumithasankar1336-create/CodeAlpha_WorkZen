// Transparent rule-based task scoring (NOT an AI model). Higher score = work on it sooner.
const { daysUntil } = require('../utils/dates');
const WEIGHTS = { Low: 10, Medium: 25, High: 45, Urgent: 65 };
const CATEGORIES = ['Do First', 'Due Soon', 'In Progress', 'Can Wait', 'Completed'];

function scoreTask(task, now = new Date()) {
  if (task.status === 'Completed') return { score: 0, category: 'Completed', reasons: ['Task is already completed'] };
  let score = WEIGHTS[task.priority] || 25;
  const reasons = [`${task.priority} priority (+${score})`];
  let d = null;
  if (task.dueDate) {
    d = daysUntil(task.dueDate, now);
    let pts = 0;
    if (d < 0) { pts = 40 + Math.min(20, -d * 2); reasons.push(`Overdue by ${-d} day${-d === 1 ? '' : 's'} (+${pts})`); }
    else if (d === 0) { pts = 30; reasons.push('Due today (+30)'); }
    else if (d <= 3) { pts = 20; reasons.push(`Due in ${d} day${d === 1 ? '' : 's'} (+20)`); }
    else if (d <= 7) { pts = 10; reasons.push(`Due in ${d} days (+10)`); }
    else reasons.push(`Deadline is ${d} days away (+0)`);
    score += pts;
  } else reasons.push('No deadline set (+0)');
  if (task.status === 'In Progress') { score += 5; reasons.push('Already in progress (+5)'); }
  let category = 'Can Wait';
  if ((d !== null && d < 0) || score >= 70) category = 'Do First';
  else if (d !== null && d <= 3) category = 'Due Soon';
  else if (task.status === 'In Progress' || task.status === 'In Review') category = 'In Progress';
  return { score, category, reasons };
}
const STATUS_ORDER = { 'To Do': 0, 'In Progress': 1, 'In Review': 2, Completed: 3 };
function rank(tasks, sort = 'recommended', now = new Date()) {
  const out = tasks.map((t) => ({ ...t, rec: scoreTask(t, now) }));
  const due = (t) => (t.dueDate ? new Date(t.dueDate).getTime() : Infinity);
  const cmp = { recommended: (a, b) => b.rec.score - a.rec.score, deadline: (a, b) => due(a) - due(b), status: (a, b) => STATUS_ORDER[a.status] - STATUS_ORDER[b.status] || b.rec.score - a.rec.score };
  return out.sort(cmp[sort] || cmp.recommended);
}
module.exports = { scoreTask, rank, WEIGHTS, CATEGORIES };
