// Holds the Socket.IO instance so controllers/services can emit without importing the server.
let io = null;
module.exports = {
  setIo: (i) => { io = i; },
  getIo: () => io,
  toProject: (projectId, event, payload) => io && io.to(`project:${projectId}`).emit(event, payload),
  toUser: (userId, event, payload) => io && io.to(`user:${userId}`).emit(event, payload),
  joinUser: (userId, projectId) => io && io.in(`user:${userId}`).socketsJoin(`project:${projectId}`),
  leaveUser: (userId, projectId) => io && io.in(`user:${userId}`).socketsLeave(`project:${projectId}`),
};
