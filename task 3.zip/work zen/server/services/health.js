// Project health score (0-100): an informational indicator built from documented factors. It does not predict outcomes.
const config = require('../config');
const { daysUntil } = require('../utils/dates');
const clamp = (n, a = 0, b = 1) => Math.min(b, Math.max(a, n));

function computeHealth(project, tasks, now = new Date(), cfg = config.health) {
  const total = tasks.length, done = tasks.filter((t) => t.status === 'Completed').length;
  const open = tasks.filter((t) => t.status !== 'Completed');
  const overdue = open.filter((t) => t.dueDate && daysUntil(t.dueDate, now) < 0).length;
  const upcoming = open.filter((t) => t.dueDate && daysUntil(t.dueDate, now) >= 0 && daysUntil(t.dueDate, now) <= 3).length;
  const completion = total ? done / total : 0;
  if (!total) return { score: null, status: 'No Data', progress: 0, counts: { total, done, open: 0, overdue, upcoming }, factors: [{ name: 'Tasks', points: 0, max: 100, note: 'Add tasks to calculate a health score.' }] };
  const overdueRatio = open.length ? overdue / open.length : 0;
  const upcomingRatio = open.length ? upcoming / open.length : 0;
  let expected = 0;
  if (project.startDate && project.deadline) {
    const s = new Date(project.startDate).getTime(), e = new Date(project.deadline).getTime();
    expected = e > s ? clamp((now.getTime() - s) / (e - s)) : 1;
  } else if (project.deadline && now > new Date(project.deadline)) expected = 1;
  const gap = clamp(expected - completion);
  const w = cfg.weights;
  const factors = [
    { name: 'Task completion', points: w.completion * completion, max: w.completion, note: `${done} of ${total} tasks completed (${Math.round(completion * 100)}%)` },
    { name: 'Overdue ratio', points: w.overdue * (1 - overdueRatio), max: w.overdue, note: `${overdue} of ${open.length} open tasks overdue` },
    { name: 'Upcoming deadlines', points: w.upcoming * (1 - upcomingRatio), max: w.upcoming, note: `${upcoming} open task${upcoming === 1 ? '' : 's'} due within 3 days` },
    { name: 'Progress vs schedule', points: w.schedule * (1 - gap), max: w.schedule, note: project.deadline ? `${Math.round(expected * 100)}% of timeline elapsed, ${Math.round(completion * 100)}% complete` : 'No project deadline set - schedule factor neutral' },
  ].map((f) => ({ ...f, points: Math.round(f.points * 10) / 10 }));
  const score = Math.round(factors.reduce((s, f) => s + f.points, 0));
  const status = score >= cfg.healthy ? 'Healthy' : score >= cfg.attention ? 'Needs Attention' : 'At Risk';
  return { score, status, progress: Math.round(completion * 100), counts: { total, done, open: open.length, overdue, upcoming }, factors };
}
module.exports = { computeHealth };
