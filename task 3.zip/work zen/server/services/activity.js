const { Activity } = require('../models');
const events = require('./events');
async function log(projectId, user, action, taskId = null) {
  const a = await Activity.create({ project: projectId, user: user._id, action, task: taskId });
  events.toProject(projectId, 'activity:new', { projectId: String(projectId), activity: { _id: a._id, action, createdAt: a.createdAt, task: taskId, user: { _id: user._id, name: user.name, avatarColor: user.avatarColor } } });
  return a;
}
module.exports = { log };
