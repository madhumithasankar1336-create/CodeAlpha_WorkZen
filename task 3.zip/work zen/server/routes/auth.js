const router = require('express').Router();
const { body } = require('express-validator');
const { validate } = require('../utils/http');
const { authenticate } = require('../middleware/auth');
const c = require('../controllers/auth');
const email = body('email').isString().trim().toLowerCase().isEmail().withMessage('Enter a valid email address');
router.post('/register', body('name').isString().trim().isLength({ min: 2, max: 60 }).withMessage('Name must be 2-60 characters'), email,
  body('password').isString().isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters').matches(/[A-Za-z]/).withMessage('Password needs a letter').matches(/\d/).withMessage('Password needs a number'), validate, c.register);
router.post('/login', email, body('password').isString().notEmpty().withMessage('Password is required'), validate, c.login);
router.post('/logout', c.logout);
router.get('/me', authenticate, c.me);
module.exports = router;
