const router = require('express').Router();
const { body, param } = require('express-validator');
const { validate } = require('../utils/http');
const { PROJECT_STATUSES } = require('../models');
const c = require('../controllers/projects');
const fields = (req) => [
  body('name')[req ? 'exists' : 'optional']().bail().isString().trim().isLength({ min: 2, max: 80 }).withMessage('Project name must be 2-80 characters'),
  body('description').optional({ nullable: true }).isString().isLength({ max: 1000 }).withMessage('Description is too long'),
  body('status').optional().isIn(PROJECT_STATUSES).withMessage('Invalid status'),
  body('startDate').optional({ checkFalsy: true }).isISO8601().withMessage('Invalid start date'),
  body('deadline').optional({ checkFalsy: true }).isISO8601().withMessage('Invalid deadline'),
];
const id = param('id').isMongoId().withMessage('Invalid project id');
router.get('/', c.list);
router.post('/', fields(true), validate, c.create);
router.get('/:id', id, validate, c.get);
router.put('/:id', id, fields(false), validate, c.update);
router.delete('/:id', id, validate, c.remove);
router.post('/:id/members', id, body('email').isString().trim().toLowerCase().isEmail().withMessage('Enter a valid email'), body('role').optional().isIn(['admin', 'member']).withMessage('Role must be admin or member'), validate, c.addMember);
router.patch('/:id/members/:userId', id, param('userId').isMongoId(), body('role').isIn(['admin', 'member']).withMessage('Role must be admin or member'), validate, c.setRole);
router.delete('/:id/members/:userId', id, param('userId').isMongoId(), validate, c.removeMember);
router.get('/:id/activity', id, validate, c.activity);
router.get('/:id/workload', id, validate, c.workload);
module.exports = router;
