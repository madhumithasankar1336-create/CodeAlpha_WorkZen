const router = require('express').Router();
const { body } = require('express-validator');
const { validate } = require('../utils/http');
const c = require('../controllers/users');
router.get('/me', c.profile);
router.put('/me', body('name').optional().isString().trim().isLength({ min: 2, max: 60 }).withMessage('Name must be 2-60 characters'), body('avatarColor').optional().matches(/^#[0-9a-fA-F]{6}$/).withMessage('Invalid avatar color'), validate, c.update);
router.get('/team', c.team);
module.exports = router;
