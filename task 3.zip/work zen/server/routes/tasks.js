const router = require('express').Router();
const { body, param, query } = require('express-validator');
const { validate } = require('../utils/http');
const { STATUSES, PRIORITIES } = require('../models');
const c = require('../controllers/tasks');
const id = param('id').isMongoId().withMessage('Invalid id');
const filters = [query('status').optional({ checkFalsy: true }).isIn(STATUSES), query('priority').optional({ checkFalsy: true }).isIn(PRIORITIES), query('project').optional({ checkFalsy: true }).isMongoId()];
const common = (create) => [
  body('title')[create ? 'exists' : 'optional']().bail().isString().trim().isLength({ min: 1, max: 120 }).withMessage('Title is required (max 120 characters)'),
  body('description').optional({ nullable: true }).isString().isLength({ max: 2000 }).withMessage('Description is too long'),
  body('priority').optional().isIn(PRIORITIES).withMessage('Invalid priority'),
  body('status').optional().isIn(STATUSES).withMessage('Invalid status'),
  body('startDate').optional({ checkFalsy: true }).isISO8601().withMessage('Invalid start date'),
  body('dueDate').optional({ checkFalsy: true }).isISO8601().withMessage('Invalid due date'),
];
router.get('/', filters, validate, c.list);
router.get('/prioritized', filters, validate, c.prioritized);
router.post('/', common(true), body('project').isMongoId().withMessage('Choose a project'), body('assignee').optional({ checkFalsy: true }).isMongoId().withMessage('Invalid assignee'), validate, c.create);
router.delete('/comments/:id', id, validate, c.removeComment);
router.get('/:id', id, validate, c.get);
router.put('/:id', id, common(false), validate, c.update);
router.delete('/:id', id, validate, c.remove);
router.patch('/:id/status', id, body('status').isIn(STATUSES).withMessage('Invalid status'), validate, c.setStatus);
router.patch('/:id/assign', id, body('assignee').optional({ nullable: true, checkFalsy: true }).isMongoId().withMessage('Invalid assignee'), body('confirm').isBoolean().withMessage('Confirmation required'), validate, c.assign);
router.post('/:id/comments', id, body('text').isString().trim().isLength({ min: 1, max: 1000 }).withMessage('Comment must be 1-1000 characters'), validate, c.addComment);
module.exports = router;
