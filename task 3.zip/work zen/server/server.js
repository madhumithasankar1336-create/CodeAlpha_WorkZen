const http = require('http');
const config = require('./config');
const connectDB = require('./config/db');
const app = require('./app');
const attachSocket = require('./socket');

(async () => {
  try { await connectDB(); } catch { process.exit(1); }
  const server = http.createServer(app);
  attachSocket(server);
  server.listen(config.port, () => console.log(`[server] WORKZEN running at http://localhost:${config.port}`));
})();
