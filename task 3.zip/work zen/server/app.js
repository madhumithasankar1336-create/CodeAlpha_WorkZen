const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const config = require('./config');
const { authenticate, csrf } = require('./middleware/auth');
const { HttpError } = require('./utils/http');
const misc = require('./routes/misc');

const app = express();
const client = path.join(__dirname, '..', 'client');
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'", 'ws:', 'wss:'], upgradeInsecureRequests: null } } }));
app.use(cors({ origin: config.clientUrl, credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

const skip = () => config.env === 'test';
const limiter = (max) => rateLimit({ windowMs: 15 * 60 * 1000, max, standardHeaders: true, legacyHeaders: false, skip, message: { success: false, message: 'Too many requests, please try again later.' } });
app.use('/api', limiter(600));
app.get('/api/health', (req, res) => res.json({ success: true, data: { status: 'ok', time: new Date().toISOString() } }));
app.use('/api/auth', limiter(30), csrf, require('./routes/auth'));
const guarded = [csrf, authenticate];
app.use('/api/users', guarded, require('./routes/users'));
app.use('/api/projects', guarded, require('./routes/projects'));
app.use('/api/tasks', guarded, require('./routes/tasks'));
app.use('/api/notifications', guarded, misc.notifications);
app.use('/api/focus', guarded, misc.focus);
app.use('/api/insights', guarded, misc.insights);
app.use('/api', (req, res) => res.status(404).json({ success: false, message: 'Endpoint not found' }));

app.use(express.static(client, { extensions: ['html'] }));
app.use((req, res) => res.status(404).sendFile(path.join(client, '404.html')));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ success: false, message: err.message, errors: err.errors });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ success: false, message: 'Malformed JSON body' });
  if (err.name === 'ValidationError') return res.status(422).json({ success: false, message: Object.values(err.errors)[0].message });
  if (err.name === 'CastError') return res.status(400).json({ success: false, message: 'Invalid identifier' });
  if (err.code === 11000) return res.status(409).json({ success: false, message: 'A record with these details already exists' });
  console.error('[error]', err);
  res.status(500).json({ success: false, message: 'Something went wrong on the server' });
});
module.exports = app;
