process.env.NODE_ENV = 'test';
process.env.APP_TIMEZONE = 'UTC';
const test = require('node:test');
const assert = require('node:assert');
const { scoreTask, rank } = require('../services/priority');
const { computeHealth } = require('../services/health');
const { streakFrom } = require('../services/achievements');
const { daysUntil, toDate, dayKey } = require('../utils/dates');

const NOW = new Date('2026-10-28T10:00:00Z');
const due = (n) => toDate(new Date(NOW.getTime() + n * 864e5).toISOString().slice(0, 10));

test('dates: daysUntil uses calendar days', () => {
  assert.strictEqual(daysUntil(due(0), NOW), 0);
  assert.strictEqual(daysUntil(due(3), NOW), 3);
  assert.strictEqual(daysUntil(due(-2), NOW), -2);
  assert.strictEqual(dayKey(NOW, 'UTC'), '2026-10-28');
});
test('priority: overdue urgent task ranks highest and is Do First', () => {
  const r = scoreTask({ priority: 'Urgent', status: 'To Do', dueDate: due(-2) }, NOW);
  assert.strictEqual(r.category, 'Do First');
  assert.ok(r.score >= 100);
  assert.ok(r.reasons.some((x) => /Overdue/.test(x)));
});
test('priority: high priority due today is Do First; medium due in 3 days is Due Soon; low distant is Can Wait', () => {
  assert.strictEqual(scoreTask({ priority: 'High', status: 'To Do', dueDate: due(0) }, NOW).category, 'Do First');
  assert.strictEqual(scoreTask({ priority: 'Medium', status: 'To Do', dueDate: due(3) }, NOW).category, 'Due Soon');
  assert.strictEqual(scoreTask({ priority: 'Low', status: 'To Do', dueDate: due(30) }, NOW).category, 'Can Wait');
  assert.strictEqual(scoreTask({ priority: 'Low', status: 'In Progress', dueDate: due(30) }, NOW).category, 'In Progress');
  assert.strictEqual(scoreTask({ priority: 'Urgent', status: 'Completed', dueDate: due(-5) }, NOW).category, 'Completed');
});
test('priority: rank sorts by recommended, deadline and status', () => {
  const tasks = [{ priority: 'Low', status: 'To Do', dueDate: due(1) }, { priority: 'Urgent', status: 'To Do', dueDate: due(-1) }, { priority: 'High', status: 'Completed', dueDate: due(0) }];
  assert.strictEqual(rank(tasks, 'recommended', NOW)[0].priority, 'Urgent');
  assert.strictEqual(rank(tasks, 'deadline', NOW)[0].priority, 'Urgent');
  assert.strictEqual(rank(tasks, 'status', NOW)[2].status, 'Completed');
});
test('health: no tasks gives no score; healthy and at-risk projects are classified', () => {
  assert.strictEqual(computeHealth({}, [], NOW).score, null);
  const good = computeHealth({}, [{ status: 'Completed' }, { status: 'Completed' }, { status: 'In Progress', dueDate: due(20) }], NOW);
  assert.strictEqual(good.status, 'Healthy');
  const bad = computeHealth({}, [{ status: 'To Do', dueDate: due(-3) }, { status: 'To Do', dueDate: due(-1) }], NOW);
  assert.strictEqual(bad.status, 'At Risk');
  assert.ok(bad.factors.length === 4 && bad.score >= 0 && bad.score <= 100);
});
test('health: schedule factor penalises being behind the timeline', () => {
  const p = { startDate: due(-10), deadline: due(2) };
  const behind = computeHealth(p, [{ status: 'To Do', dueDate: due(10) }, { status: 'To Do', dueDate: due(10) }], NOW);
  const ahead = computeHealth(p, [{ status: 'Completed' }, { status: 'Completed' }], NOW);
  assert.ok(ahead.score > behind.score);
});
test('streaks: consecutive days, gaps and "yesterday still counts"', () => {
  assert.deepStrictEqual(streakFrom(['2026-10-26', '2026-10-27', '2026-10-28'], '2026-10-28'), { current: 3, longest: 3 });
  assert.deepStrictEqual(streakFrom(['2026-10-26', '2026-10-27'], '2026-10-28'), { current: 2, longest: 2 });
  assert.deepStrictEqual(streakFrom(['2026-10-20', '2026-10-21', '2026-10-27'], '2026-10-28'), { current: 1, longest: 2 });
  assert.deepStrictEqual(streakFrom([], '2026-10-28'), { current: 0, longest: 0 });
});
