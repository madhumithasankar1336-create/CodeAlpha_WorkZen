process.env.NODE_ENV = 'test';
const test = require('node:test');
const assert = require('node:assert');
const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../app');

// ---- Tests that need no database: validation, auth guards, static pages ----
test('GET /api/health responds ok', async () => { const r = await request(app).get('/api/health'); assert.strictEqual(r.status, 200); assert.strictEqual(r.body.success, true); });
test('protected endpoints reject anonymous requests with 401', async () => {
  for (const p of ['/api/auth/me', '/api/projects', '/api/tasks', '/api/notifications', '/api/focus', '/api/insights/dashboard', '/api/users/me']) {
    const r = await request(app).get(p); assert.strictEqual(r.status, 401, p);
  }
});
test('a forged JWT is rejected', async () => { const r = await request(app).get('/api/projects').set('Cookie', 'wz_token=not.a.jwt'); assert.strictEqual(r.status, 401); });
test('register validation returns 422 with messages', async () => {
  let r = await request(app).post('/api/auth/register').send({ name: 'A', email: 'bad', password: 'short' });
  assert.strictEqual(r.status, 422); assert.ok(r.body.errors.length >= 2);
  r = await request(app).post('/api/auth/register').send({ name: 'Valid Name', email: 'a@b.co', password: 'longpassword' });
  assert.strictEqual(r.status, 422); assert.match(r.body.message, /number/);
});
test('login validation rejects malformed/injection payloads before touching the database', async () => {
  const r = await request(app).post('/api/auth/login').send({ email: { $gt: '' }, password: { $gt: '' } }); assert.strictEqual(r.status, 422);
});
test('state-changing request with a session cookie but no CSRF header is blocked', async () => {
  const r = await request(app).post('/api/projects').set('Cookie', 'wz_token=x; wz_csrf=abc').send({ name: 'X' }); assert.strictEqual(r.status, 403);
});
test('unknown API route returns JSON 404; unknown page returns the 404 page', async () => {
  let r = await request(app).get('/api/nope'); assert.strictEqual(r.status, 404); assert.strictEqual(r.body.success, false);
  r = await request(app).get('/definitely-missing'); assert.strictEqual(r.status, 404); assert.match(r.text, /404/);
});
test('static pages are served', async () => {
  for (const p of ['/', '/login.html', '/register.html', '/dashboard.html', '/css/style.css', '/js/app.js']) { const r = await request(app).get(p); assert.strictEqual(r.status, 200, p); }
});
test('security headers are present and X-Powered-By is hidden', async () => {
  const r = await request(app).get('/api/health'); assert.ok(r.headers['content-security-policy']); assert.strictEqual(r.headers['x-powered-by'], undefined);
});

// ---- Full integration flow: runs only when MongoDB is reachable (MONGODB_URI_TEST or local default) ----
const uri = process.env.MONGODB_URI_TEST || 'mongodb://127.0.0.1:27017/workzen_test';
let dbUp = false;
test('integration: connect to MongoDB', async (t) => {
  try { await mongoose.connect(uri, { serverSelectionTimeoutMS: 1500 }); await mongoose.connection.dropDatabase(); dbUp = true; } catch { t.skip('MongoDB not reachable - integration tests skipped'); }
});
const client = () => {
  const agent = request.agent(app); let csrf = '';
  const wrap = (m) => (u, b) => { const r = agent[m](u); if (m !== 'get') r.set('x-csrf-token', csrf); return b ? r.send(b) : r; };
  return { get: wrap('get'), post: wrap('post'), put: wrap('put'), patch: wrap('patch'), delete: wrap('delete'), setCsrf: (res) => { const c = (res.headers['set-cookie'] || []).find((x) => x.startsWith('wz_csrf=')); if (c) csrf = c.split(';')[0].split('=')[1]; } };
};
test('integration: auth, projects, tasks, permissions, comments, notifications, focus, badges', async (t) => {
  if (!dbUp) return t.skip('no MongoDB');
  const A = client(), B = client(), C = client();
  const reg = async (c, name, email) => { const r = await c.post('/api/auth/register', { name, email, password: 'Passw0rdX' }); assert.strictEqual(r.status, 201); c.setCsrf(r); return r.body.data; };
  const a = await reg(A, 'Alice Admin', 'alice@test.io'), b = await reg(B, 'Bob Member', 'bob@test.io'); await reg(C, 'Carl Outsider', 'carl@test.io');
  assert.strictEqual((await request(app).post('/api/auth/register').send({ name: 'Dup', email: 'alice@test.io', password: 'Passw0rdX' })).status, 409);
  assert.strictEqual((await A.get('/api/auth/me')).body.data.email, 'alice@test.io');
  const p = (await A.post('/api/projects', { name: 'Apollo', deadline: '2030-01-01' })).body.data;
  assert.strictEqual((await B.get('/api/projects/' + p._id)).status, 404); // non-member cannot see it
  assert.strictEqual((await A.post(`/api/projects/${p._id}/members`, { email: 'bob@test.io' })).status, 201);
  const task = (await A.post('/api/tasks', { title: 'Write spec', project: p._id, assignee: b._id, priority: 'High', dueDate: '2030-01-01' })).body.data;
  assert.strictEqual((await C.get('/api/tasks/' + task._id)).status, 404);
  assert.strictEqual((await C.post('/api/tasks', { title: 'x', project: p._id })).status, 404);
  assert.strictEqual((await B.patch(`/api/tasks/${task._id}/status`, { status: 'Completed' })).status, 200);
  assert.strictEqual((await B.patch(`/api/tasks/${task._id}/assign`, { assignee: a._id, confirm: true })).status, 403); // members cannot reassign
  assert.strictEqual((await A.patch(`/api/tasks/${task._id}/assign`, { assignee: a._id })).status, 422); // confirmation required
  assert.strictEqual((await A.patch(`/api/tasks/${task._id}/assign`, { assignee: a._id, confirm: true })).status, 200);
  const cm = (await B.post(`/api/tasks/${task._id}/comments`, { text: 'Looks good' })).body.data;
  assert.strictEqual((await A.delete('/api/tasks/comments/' + cm._id)).status, 200); // manager may delete
  const bn = (await B.get('/api/notifications')).body.data;
  const an = (await A.get('/api/notifications')).body.data;
  assert.ok(an.items.length >= 1);
  assert.strictEqual((await C.patch(`/api/notifications/${an.items[0]._id}/read`)).status, 404); // ownership enforced
  assert.strictEqual((await B.patch(`/api/notifications/${an.items[0]._id}/read`)).status, 404);
  assert.ok(bn.items.length >= 1);
  assert.strictEqual((await A.post('/api/notifications/read-all')).status, 200);
  const s = (await A.post('/api/focus/start', { type: 'focus' })).body.data;
  assert.strictEqual((await A.post(`/api/focus/${s._id}/complete`)).status, 400); // unfinished session cannot be completed
  assert.strictEqual((await A.post(`/api/focus/${s._id}/abandon`)).status, 200);
  const h = (await A.get('/api/focus')).body.data; assert.strictEqual(h.stats.totalSessions, 0);
  const dash = (await A.get('/api/insights/dashboard')).body.data; assert.strictEqual(dash.totals.projects, 1); assert.strictEqual(dash.totals.tasks, 1);
  assert.strictEqual((await B.delete('/api/projects/' + p._id)).status, 403);
  assert.strictEqual((await A.delete('/api/projects/' + p._id)).status, 200);
});
test('integration: cleanup', async () => { if (dbUp) { await mongoose.connection.dropDatabase(); } await mongoose.disconnect(); });
