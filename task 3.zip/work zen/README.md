# WORKZEN — Smart Team Collaboration & Project Management Platform

> **Plan Smarter. Collaborate Better. Achieve Together.**

Full-stack project management tool built for the **Code Alpha Full Stack Development Internship – Task 3**.
Vanilla HTML/CSS/JS frontend, Node.js + Express REST API, MongoDB (Mongoose), JWT auth in HttpOnly cookies, Socket.IO real-time updates.

## Main features
Registration/login/logout, profile editing · project CRUD with roles (Owner/Admin/Member) enforced on the backend · task CRUD, assignment, priorities, deadlines, search & filters · Kanban board (drag-and-drop + keyboard status menu, rollback on server rejection) · task comments and activity timelines · notifications center with real-time unread count · dashboard with statistics calculated from database records · light/dark theme · responsive layout.

## Unique features
| Feature | Where | How it works |
|---|---|---|
| Smart Task Prioritizer | My Tasks | Transparent rule-based score (priority weight + deadline proximity + status). Every task shows *why*. **Not an AI model.** See `server/services/priority.js`. |
| Focus Mode | Focus Mode | 25/5/15-minute timer; sessions stored in MongoDB; pause/resume; survives refresh; unfinished sessions are stored as `abandoned`, never `completed`. |
| Team Pulse | Team Pulse | Period/project filters; informational indicators, members listed alphabetically (no ranking). |
| Deadline Radar | Deadline Radar | Overdue / today / ≤3 days / project deadlines / completed, computed from real dates, filters by project/assignee/priority. |
| Streaks & Badges | Achievements | First Task Completed, Focus Starter, Deadline Champion, Team Collaborator, Weekly Achiever. Criteria shown in the UI; unique index prevents duplicates. |
| Workload Balance | Project → Workload | Per-member counts, configurable "high load" rules (env or on-page); reassignment is owner/admin only and requires confirmation. |
| Project Health Score | Project → Overview | 0–100 from completion, overdue ratio, upcoming deadlines, progress vs. schedule. Weights in `server/config/index.js`. An indicator, not a prediction. |
| Quick Capture | every page | Global "Quick add task" button and floating **+** button. |
| Live Collaboration | everywhere | Socket.IO with cookie-JWT auth; rooms only for projects you belong to; notifications persisted in MongoDB with de-duplication keys. |
| Comments & Timeline | Task modal / Project | Chronological, authorization-checked. |

**Badge criteria:** First Task = 1 task assigned to you completed (task must exist ≥ 1 min) · Focus Starter = 1 completed focus session · Deadline Champion = 5 tasks done on/before due date · Team Collaborator = 3 comments on tasks created by teammates · Weekly Achiever = 5 tasks done in 7 days. Duplicate task titles per project are ignored.

**Date/timezone strategy:** all "today"/overdue/streak logic uses one IANA timezone (`APP_TIMEZONE`, default `UTC`). Due dates are stored at 12:00 UTC of the chosen day.

**Health formula (default weights):** completion 40 + (1 − overdue ratio) 30 + (1 − due-within-3-days ratio) 15 + (1 − schedule gap) 15. ≥75 Healthy, ≥50 Needs Attention, else At Risk.

## Technology stack
Frontend: HTML5, CSS3, vanilla JS, Fetch API · Backend: Node.js, Express · DB: MongoDB + Mongoose · Auth: JWT, bcryptjs · Realtime: Socket.IO · Security/other: helmet, cors, express-rate-limit, express-validator, dotenv, cookie-parser.

## Folder structure
```
workzen/
├── client/            index, login, register, dashboard, projects, project-details, kanban, tasks,
│   ├── css/style.css  team-pulse, deadline-radar, focus-mode, notifications, achievements, profile, 404 (.html)
│   ├── js/            api.js auth.js app.js(shell, quick-add) task-modal.js + one script per page
│   └── assets/        logo.svg favicon.svg
├── server/
│   ├── config/ models/ controllers/ routes/ middleware/ services/ socket/ utils/ tests/
│   ├── app.js         Express app (security, routes, static client)
│   └── server.js      DB connection + HTTP + Socket.IO
├── .env.example  .gitignore  package.json  README.md
```

## Installation
```bash
npm install
cp .env.example .env        # then set JWT_SECRET to a long random string
```
Generate a secret: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

### MongoDB setup
Option A – local: install MongoDB Community Edition and start it (`mongod`, or `brew services start mongodb-community`, or `sudo systemctl start mongod`). Default URI: `mongodb://127.0.0.1:27017/workzen`.
Option B – Docker: `docker run -d --name mongo -p 27017:27017 mongo:7`
Option C – MongoDB Atlas: create a free cluster, add your IP, copy the connection string into `MONGODB_URI`.
The server checks the connection at startup and exits with a clear message if MongoDB is unreachable.

### Environment variables
`PORT`, `MONGODB_URI`, `JWT_SECRET`, `CLIENT_URL` (CORS origin, must equal the URL you open in the browser), `NODE_ENV` (`production` enables Secure cookies — requires HTTPS) · optional: `APP_TIMEZONE`, `WORKLOAD_MAX_OPEN`, `WORKLOAD_MAX_OVERDUE`.

## Run
```bash
npm start        # http://localhost:5000  (Express serves the client too)
npm run dev      # auto-restart on changes
```
Open http://localhost:5000, register two accounts (use a second browser/private window) to try assignments, notifications and live updates.

## API overview (all JSON: `{success, data}` / `{success:false, message, errors?}`)
| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/register · login · logout`, `GET /api/auth/me` |
| Users | `GET/PUT /api/users/me`, `GET /api/users/team` |
| Projects | `GET/POST /api/projects`, `GET/PUT/DELETE /api/projects/:id`, `POST /:id/members`, `PATCH/DELETE /:id/members/:userId`, `GET /:id/activity`, `GET /:id/workload` |
| Tasks | `GET/POST /api/tasks`, `GET /api/tasks/prioritized`, `GET/PUT/DELETE /api/tasks/:id`, `PATCH /:id/status`, `PATCH /:id/assign`, `GET…POST /:id/comments`, `DELETE /api/tasks/comments/:id` |
| Notifications | `GET /api/notifications`, `GET /unread-count`, `PATCH /:id/read`, `POST /read-all` |
| Focus | `POST /api/focus/start`, `GET /active`, `POST /:id/pause · resume · complete · abandon`, `GET /api/focus` |
| Insights | `GET /api/insights/dashboard · team-pulse · deadlines · achievements` |

Socket events: `task:created`, `task:updated`, `comment:new`, `comment:deleted`, `activity:new`, `project:updated`, `project:deleted`, `notification:new`. REST remains the source of truth; events just trigger re-fetches.

## Security notes
bcrypt (12 rounds) password hashing · JWT in HttpOnly SameSite=Lax cookie (Secure in production) · double-submit CSRF token (`wz_csrf` cookie + `x-csrf-token` header) on state-changing requests · project membership checked on every project/task/comment/activity request (non-members get 404) · roles checked server-side · helmet + CSP · rate limiting (stricter on auth) · express-validator on all inputs · generic 500 errors · no secrets in client code · profile updates only accept `name` and `avatarColor`.

## Testing
```bash
npm test
```
* `unit.test.js` – prioritizer, health score, streaks, date logic (no DB needed).
* `api.test.js` – validation, auth guards, CSRF, headers, static pages (no DB needed) **plus** a full integration flow (auth, project/task permissions, reassignment confirmation, comments, notification ownership, focus-session rules, dashboard) that runs automatically **only when MongoDB is reachable** (`MONGODB_URI_TEST`, default `mongodb://127.0.0.1:27017/workzen_test`; the test DB is dropped). Otherwise those tests are reported as skipped.

## Common errors
* **`Could not connect to MongoDB`** – start `mongod` / Docker container or fix `MONGODB_URI`.
* **Redirected to login repeatedly** – cookies blocked, or `NODE_ENV=production` over plain HTTP (Secure cookie). Use HTTPS or `NODE_ENV=development` locally.
* **403 Invalid CSRF token** – log out and in again to refresh cookies; open the app through the same origin as `CLIENT_URL`.
* **Port in use** – change `PORT`.
* **Sessions reset on restart** – set a fixed `JWT_SECRET`.

## Future ideas
Email invites & reminders, file attachments, @mentions, recurring tasks, calendar view, CSV export, 2FA, per-user timezones, Playwright end-to-end tests.
