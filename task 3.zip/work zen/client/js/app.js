(function () {
  const WZ = (window.WZ = {});
  const esc = (WZ.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])));
  const $ = (WZ.$ = (s, r = document) => r.querySelector(s));
  WZ.$$ = (s, r = document) => [...r.querySelectorAll(s)];
  WZ.date = (iso) => { if (!iso) return '—'; const [y, m, d] = iso.slice(0, 10).split('-'); return new Date(+y, m - 1, +d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); };
  WZ.dt = (iso) => new Date(iso).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  WZ.ago = (iso) => { const s = (Date.now() - new Date(iso)) / 1000; return s < 60 ? 'just now' : s < 3600 ? Math.floor(s / 60) + 'm ago' : s < 86400 ? Math.floor(s / 3600) + 'h ago' : Math.floor(s / 86400) + 'd ago'; };
  WZ.initials = (n) => String(n).split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  WZ.avatar = (u, sz = 28) => u ? `<span class="avatar" title="${esc(u.name)}" style="background:${esc(u.avatarColor || '#8B5CF6')};width:${sz}px;height:${sz}px;font-size:${Math.round(sz * 0.4)}px">${esc(WZ.initials(u.name))}</span>` : '<span class="avatar ghost" title="Unassigned">?</span>';
  WZ.prio = (p) => `<span class="pill p-${esc(String(p).toLowerCase())}">${esc(p)}</span>`;
  WZ.healthPill = (h) => h.score == null ? '<span class="pill p-low">No data</span>' : `<span class="pill ${h.status === 'Healthy' ? 's-ok' : h.status === 'At Risk' ? 's-bad' : 's-warn'}">${esc(h.status)} · ${h.score}</span>`;
  WZ.loader = '<div class="loader" role="status" aria-label="Loading"></div>';
  WZ.empty = (m) => `<div class="empty">${esc(m)}</div>`;
  WZ.debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  WZ.refresh = () => document.dispatchEvent(new CustomEvent('wz:refresh'));
  WZ.donut = (pct, size = 120) => { const r = 48, c = 2 * Math.PI * r; return `<svg width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="${pct}% complete"><defs><linearGradient id="dg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22D3EE"/><stop offset="1" stop-color="#8B5CF6"/></linearGradient></defs><circle cx="60" cy="60" r="${r}" fill="none" stroke="rgba(148,163,184,.25)" stroke-width="12"/><circle cx="60" cy="60" r="${r}" fill="none" stroke="url(#dg)" stroke-width="12" stroke-linecap="round" stroke-dasharray="${(c * pct) / 100} ${c}" transform="rotate(-90 60 60)"/><text x="60" y="67" text-anchor="middle" font-size="22" font-weight="800" fill="currentColor">${pct}%</text></svg>`; };
  WZ.bars = (items) => { const max = Math.max(1, ...items.map((i) => i.value)); return `<div class="bars">${items.map((i) => `<div title="${esc(i.label)}: ${i.value}"><i style="height:${(i.value / max) * 90}%"></i>${esc(i.short)}</div>`).join('')}</div>`; };

  WZ.toast = (msg, type = 'info') => {
    let box = $('.toasts'); if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
    const t = document.createElement('div'); t.className = 'toast ' + type; t.textContent = msg; box.appendChild(t); setTimeout(() => t.remove(), 4000);
  };
  WZ.modal = (html, onClose) => {
    const o = document.createElement('div'); o.className = 'overlay'; o.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`; document.body.appendChild(o);
    const close = () => { document.removeEventListener('keydown', key); o.remove(); onClose && onClose(); };
    const key = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', key);
    o.addEventListener('mousedown', (e) => { if (e.target === o) close(); });
    return { el: o.firstChild, close };
  };
  WZ.projects = async (force) => { if (!WZ._p || force) WZ._p = await api.get('/projects'); return WZ._p; };
  WZ.projectOptions = (list, sel, all) => (all ? `<option value="">${all}</option>` : '') + list.map((p) => `<option value="${p._id}" ${p._id === sel ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
  WZ.memberOptions = (project, sel, blank = 'Unassigned') => `<option value="">${blank}</option>` + (project ? project.members : []).map((m) => `<option value="${m.user._id}" ${m.user._id === sel ? 'selected' : ''}>${esc(m.user.name)}</option>`).join('');

  // Create / edit task form. Quick Capture uses quick:true (title, project, assignee, priority, deadline only).
  WZ.taskForm = async (task, opts = {}) => {
    const projects = (await WZ.projects(true)).filter((p) => p.status !== 'Completed' || (task && task.project._id === p._id));
    if (!projects.length) { WZ.toast('Create a project first, then add tasks.', 'error'); return null; }
    const pid = task ? task.project._id : opts.project || projects[0]._id;
    return new Promise((resolve) => {
      let saved = null;
      const m = WZ.modal(`<h2>${task ? 'Edit task' : opts.quick ? '⚡ Quick capture' : 'New task'}</h2><form novalidate>
        <label>Title</label><input name="title" maxlength="120" value="${esc(task ? task.title : '')}" required>
        <div class="grid g2" style="gap:0 12px;grid-template-columns:1fr 1fr"><div><label>Project</label><select name="project" ${task ? 'disabled' : ''}>${WZ.projectOptions(projects, pid)}</select></div>
        <div><label>Assignee</label><select name="assignee" ${task ? 'disabled' : ''}></select></div>
        <div><label>Priority</label><select name="priority">${['Low', 'Medium', 'High', 'Urgent'].map((p) => `<option ${((task && task.priority) || 'Medium') === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
        <div><label>Deadline</label><input type="date" name="dueDate" value="${task && task.dueDate ? task.dueDate.slice(0, 10) : ''}"></div>
        ${opts.quick ? '' : `<div><label>Start date</label><input type="date" name="startDate" value="${task && task.startDate ? task.startDate.slice(0, 10) : ''}"></div><div><label>Status</label><select name="status">${['To Do', 'In Progress', 'In Review', 'Completed'].map((s) => `<option ${((task && task.status) || 'To Do') === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>`}</div>
        ${opts.quick ? '' : `<label>Description</label><textarea name="description" rows="3" maxlength="2000">${esc(task ? task.description : '')}</textarea>`}
        <div class="field-err" role="alert"></div><div class="row" style="justify-content:flex-end"><button type="button" class="btn" data-x>Cancel</button><button class="btn primary">${task ? 'Save' : 'Create task'}</button></div></form>`, () => resolve(saved));
      const f = $('form', m.el), sel = f.assignee, err = $('.field-err', f);
      const fillAssignees = () => { const p = projects.find((x) => x._id === f.project.value); sel.innerHTML = WZ.memberOptions(p, task && task.assignee ? task.assignee._id : opts.assignee || ''); };
      fillAssignees(); f.project.addEventListener('change', fillAssignees); $('[data-x]', f).onclick = m.close; f.title.focus();
      f.addEventListener('submit', async (e) => {
        e.preventDefault(); err.textContent = '';
        const title = f.title.value.trim();
        if (!title) return (err.textContent = 'Title is required');
        if (f.startDate && f.dueDate.value && f.startDate.value && f.dueDate.value < f.startDate.value) return (err.textContent = 'Due date cannot be before the start date');
        const body = { title, priority: f.priority.value, dueDate: f.dueDate.value || null };
        if (f.startDate) { body.startDate = f.startDate.value || null; body.status = f.status.value; body.description = f.description.value; }
        const btn = $('.primary', f); btn.disabled = true;
        try {
          if (task) saved = await api.put('/tasks/' + task._id, body);
          else { body.project = f.project.value; body.assignee = sel.value || undefined; saved = await api.post('/tasks', body); }
          WZ.toast(task ? 'Task updated' : 'Task created', 'success'); m.close(); WZ.refresh();
        } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
      });
    });
  };

  const NAV = [['dashboard', '🏠', 'Dashboard'], ['projects', '📁', 'Projects'], ['kanban', '🗂️', 'Kanban'], ['tasks', '✅', 'My Tasks'], ['team-pulse', '📈', 'Team Pulse'], ['deadline-radar', '📡', 'Deadline Radar'], ['focus-mode', '⏱️', 'Focus Mode'], ['notifications', '🔔', 'Notifications'], ['achievements', '🏅', 'Achievements'], ['profile', '👤', 'Profile']];
  WZ.setUnread = (n) => { $$count().forEach((e) => { e.textContent = n > 0 ? n : ''; }); };
  const $$count = () => WZ.$$('.nav .count');

  WZ.init = async (page, fn) => {
    document.documentElement.dataset.theme = localStorage.getItem('wz_theme') || 'dark';
    try { WZ.user = await api.get('/auth/me'); } catch { location.href = 'login.html'; return; }
    const app = $('#app');
    app.innerHTML = `<div class="shell"><aside class="side" id="side"><a class="brand" href="dashboard.html"><img src="assets/logo.svg" alt="">WORKZEN</a><nav class="nav">${NAV.map(([k, i, l]) => `<a href="${k}.html" class="${k === page ? 'active' : ''}" ${k === page ? 'aria-current="page"' : ''}><span>${i}</span>${l}${k === 'notifications' ? '<span class="count"></span>' : ''}</a>`).join('')}</nav></aside>
      <div><header class="top"><button class="btn menu-btn" id="menu" aria-label="Menu">☰</button><div class="grow"></div><button class="btn primary" id="qa">⚡ Quick add task</button><button class="btn" id="theme" aria-label="Toggle theme">🌓</button><a class="row" href="profile.html" style="gap:8px">${WZ.avatar(WZ.user, 32)}<span class="small">${esc(WZ.user.name)}</span></a><button class="btn sm" id="logout">Log out</button></header><main class="main" id="main">${WZ.loader}</main></div></div><button class="fab" id="fab" aria-label="Quick add task">+</button>`;
    $('#menu').onclick = () => $('#side').classList.toggle('open');
    $('#theme').onclick = () => { const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = t; localStorage.setItem('wz_theme', t); };
    $('#logout').onclick = async () => { try { await api.post('/auth/logout'); } catch { /* ignore */ } location.href = 'login.html'; };
    const qa = () => WZ.taskForm(null, { quick: true });
    $('#qa').onclick = qa; $('#fab').onclick = qa;
    api.get('/notifications/unread-count').then((r) => WZ.setUnread(r.unread)).catch(() => {});
    if (window.io) {
      const socket = (WZ.socket = io());
      const soft = WZ.debounce(WZ.refresh, 400);
      ['task:created', 'task:updated', 'comment:new', 'comment:deleted', 'activity:new', 'project:updated', 'project:deleted'].forEach((e) => socket.on(e, soft));
      socket.on('notification:new', (d) => { WZ.setUnread(d.unread); WZ.toast('🔔 ' + d.notification.message); document.dispatchEvent(new CustomEvent('wz:notification')); });
      socket.on('connect_error', () => {});
    }
    const main = $('#main');
    try { await fn(main); } catch (e) { main.innerHTML = `<div class="empty err">⚠️ ${esc(e.message)}</div>`; }
  };
  // Re-run a page loader on refresh events while keeping the loader function the single source of truth.
  WZ.live = (load) => document.addEventListener('wz:refresh', () => load().catch((e) => WZ.toast(e.message, 'error')));
})();
