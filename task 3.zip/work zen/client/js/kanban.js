WZ.init('kanban', async (main) => {
  const { esc } = WZ, COLS = ['To Do', 'In Progress', 'In Review', 'Completed'], projects = await WZ.projects(true);
  const pre = new URLSearchParams(location.search).get('project') || '';
  main.innerHTML = `<div class="row between"><h1>Kanban Board</h1><button class="btn primary" id="nt">+ New task</button></div><div class="toolbar mt"><select id="pr">${WZ.projectOptions(projects, pre, 'All projects')}</select><select id="as"><option value="">All assignees</option><option value="unassigned">Unassigned</option></select><select id="pri"><option value="">Any priority</option>${['Low', 'Medium', 'High', 'Urgent'].map((s) => `<option>${s}</option>`).join('')}</select></div><p class="small muted">Drag cards between columns, or use the status menu on each card (keyboard accessible).</p><div id="board">${WZ.loader}</div>`;
  let tasks = [];
  const fillAssignees = async () => { const team = await api.get('/users/team', { project: WZ.$('#pr').value }); const cur = WZ.$('#as').value; WZ.$('#as').innerHTML = '<option value="">All assignees</option><option value="unassigned">Unassigned</option>' + team.map((u) => `<option value="${u._id}" ${u._id === cur ? 'selected' : ''}>${esc(u.name)}</option>`).join(''); };
  const draw = () => {
    WZ.$('#board').innerHTML = `<div class="kanban">${COLS.map((c) => { const items = tasks.filter((t) => t.status === c); return `<div class="kcol" data-col="${c}"><h3>${c}<span class="pill p-low">${items.length}</span></h3>${items.map((t) => `<div class="kcard ${t.overdue ? 'overdue' : ''}" draggable="true" tabindex="0" data-id="${t._id}"><div class="row between"><b>${esc(t.title)}</b>${WZ.prio(t.priority)}</div><div class="small muted">${esc(t.project.name)}</div><div class="row between mt"><span class="small ${t.overdue ? 's-bad pill' : 'muted'}">${t.overdue ? 'Overdue · ' : '📅 '}${WZ.date(t.dueDate)}</span>${WZ.avatar(t.assignee)}</div><select class="mv mt" aria-label="Change status of ${esc(t.title)}">${COLS.map((s) => `<option ${s === t.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>`).join('') || '<div class="empty small">No tasks</div>'}</div>`; }).join('')}</div>`;
    WZ.$$('.kcard', main).forEach((card) => {
      card.ondragstart = (e) => { e.dataTransfer.setData('text/plain', card.dataset.id); card.classList.add('dragging'); };
      card.ondragend = () => card.classList.remove('dragging');
      card.onclick = (e) => { if (e.target.tagName !== 'SELECT') WZ.openTask(card.dataset.id); };
      card.onkeydown = (e) => { if (e.key === 'Enter' && e.target === card) WZ.openTask(card.dataset.id); };
      WZ.$('.mv', card).onchange = (e) => move(card.dataset.id, e.target.value);
    });
    WZ.$$('.kcol', main).forEach((col) => {
      col.ondragover = (e) => { e.preventDefault(); col.classList.add('over'); }; col.ondragleave = () => col.classList.remove('over');
      col.ondrop = (e) => { e.preventDefault(); col.classList.remove('over'); const id = e.dataTransfer.getData('text/plain'); if (id) move(id, col.dataset.col); };
    });
  };
  // Optimistic move; restore the original state and show an error if the server rejects the change.
  const move = async (id, status) => {
    const t = tasks.find((x) => x._id === id); if (!t || t.status === status) return draw();
    const prev = t.status; t.status = status; draw();
    try { const saved = await api.patch(`/tasks/${id}/status`, { status }); Object.assign(t, saved); draw(); WZ.toast(`Moved to ${status}`, 'success'); }
    catch (e) { t.status = prev; draw(); WZ.toast('Could not update task: ' + e.message, 'error'); }
  };
  const load = async () => { tasks = await api.get('/tasks', { project: WZ.$('#pr').value, assignee: WZ.$('#as').value, priority: WZ.$('#pri').value }); draw(); };
  WZ.$('#nt').onclick = () => WZ.taskForm(null, { project: WZ.$('#pr').value || undefined });
  WZ.$('#pr').onchange = async () => { await fillAssignees(); await load(); }; WZ.$('#as').onchange = load; WZ.$('#pri').onchange = load;
  await fillAssignees(); await load(); WZ.live(load);
});
