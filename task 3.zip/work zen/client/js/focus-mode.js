WZ.init('focus-mode', async (main) => {
  const { esc } = WZ, TYPES = { focus: ['Focus', 1500], short_break: ['Short break', 300], long_break: ['Long break', 900] };
  const tasks = (await api.get('/tasks', { mine: '1' })).filter((t) => t.status !== 'Completed');
  let type = 'focus', session = null, offset = 0, tick = null, completing = false;
  main.innerHTML = `<h1>Focus Mode</h1><div class="grid g2"><div class="card"><div class="row" id="types" style="justify-content:center">${Object.entries(TYPES).map(([k, v]) => `<button class="btn sm" data-ty="${k}">${v[0]} · ${v[1] / 60}m</button>`).join('')}</div><div class="timer" id="clock" role="timer" aria-live="off">25:00</div><p class="muted" style="text-align:center" id="msg">Choose a session and press Start.</p><label>Link to a task (optional)</label><select id="task"><option value="">No task</option>${tasks.map((t) => `<option value="${t._id}">${esc(t.title)} — ${esc(t.project.name)}</option>`).join('')}</select><div class="row mt" style="justify-content:center"><button class="btn primary" id="start">Start</button><button class="btn" id="pause">Pause</button><button class="btn" id="resume">Resume</button><button class="btn danger" id="reset">Reset</button></div></div><div class="card"><h2>Daily statistics</h2><div id="stats">${WZ.loader}</div></div></div><div class="card mt"><h2>Session history</h2><div id="hist"></div></div>`;
  const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  const remaining = () => { if (!session) return TYPES[type][1]; const now = Date.now() + offset, paused = session.pausedAt ? now - new Date(session.pausedAt).getTime() : 0; return Math.max(0, Math.ceil(session.plannedSeconds - (now - new Date(session.startedAt).getTime() - session.pausedMs - paused) / 1000)); };
  const ui = () => {
    const run = !!session, paused = run && !!session.pausedAt;
    WZ.$('#start').disabled = run; WZ.$('#pause').disabled = !run || paused; WZ.$('#resume').disabled = !paused; WZ.$('#reset').disabled = !run;
    WZ.$$('[data-ty]').forEach((b) => { b.classList.toggle('primary', b.dataset.ty === type); b.disabled = run; });
    WZ.$('#task').disabled = run; const r = remaining(); WZ.$('#clock').textContent = fmt(r); document.title = run ? `${fmt(r)} · WORKZEN` : 'Focus Mode — WORKZEN';
  };
  const finish = async () => {
    if (completing || !session) return; completing = true;
    try {
      const r = await api.post(`/focus/${session._id}/complete`), label = TYPES[r.type][0]; session = null; clearInterval(tick);
      WZ.$('#msg').textContent = r.type === 'focus' ? '🎉 Focus session complete! Take a break.' : '✅ Break over — ready to focus?'; WZ.toast(`${label} session completed`, 'success');
      if (r.newBadges && r.newBadges.length) WZ.toast('🏅 New badge earned!', 'success');
    } catch (e) { WZ.toast(e.message, 'error'); session = null; clearInterval(tick); }
    completing = false; ui(); history();
  };
  const run = () => { clearInterval(tick); tick = setInterval(() => { ui(); if (session && !session.pausedAt && remaining() <= 0) finish(); }, 500); ui(); };
  const history = async () => {
    const h = await api.get('/focus'), s = h.stats;
    WZ.$('#stats').innerHTML = `<div class="row" style="gap:24px"><div class="stat"><div class="v">${s.todaySessions}</div><div class="l">Sessions today</div></div><div class="stat"><div class="v">${s.todayMinutes}</div><div class="l">Minutes today</div></div><div class="stat"><div class="v">${s.totalSessions}</div><div class="l">All sessions</div></div></div><p class="small muted mt">Focus minutes, last 7 days</p>${WZ.bars(h.days.map((d) => ({ label: d.day, short: d.day.slice(8), value: d.minutes })))}`;
    WZ.$('#hist').innerHTML = h.sessions.length ? `<table><tr><th>Type</th><th>Task</th><th>Started</th><th>Duration</th><th>Status</th></tr>${h.sessions.map((x) => `<tr><td>${TYPES[x.type][0]}</td><td>${esc(x.task ? x.task.title : '—')}</td><td>${WZ.dt(x.startedAt)}</td><td>${Math.round(x.plannedSeconds / 60)}m</td><td><span class="pill ${x.status === 'completed' ? 's-ok' : 's-warn'}">${x.status}</span></td></tr>`).join('')}</table>` : WZ.empty('No sessions yet. Start your first focus session!');
  };
  WZ.$$('[data-ty]').forEach((b) => (b.onclick = () => { type = b.dataset.ty; ui(); }));
  const act = (path) => async () => { try { session = { ...session, ...(await api.post(`/focus/${session._id}/${path}`)) }; offset = session.serverNow - Date.now(); ui(); } catch (e) { WZ.toast(e.message, 'error'); } };
  WZ.$('#start').onclick = async () => { try { session = await api.post('/focus/start', { type, task: WZ.$('#task').value || undefined }); offset = session.serverNow - Date.now(); WZ.$('#msg').textContent = type === 'focus' ? 'Stay focused — you got this.' : 'Rest up.'; run(); } catch (e) { WZ.toast(e.message, 'error'); } };
  WZ.$('#pause').onclick = act('pause'); WZ.$('#resume').onclick = act('resume');
  WZ.$('#reset').onclick = async () => { if (!confirm('Reset this session? It will be recorded as abandoned, not completed.')) return; try { await api.post(`/focus/${session._id}/abandon`); } catch (e) { WZ.toast(e.message, 'error'); } session = null; clearInterval(tick); WZ.$('#msg').textContent = 'Session reset.'; ui(); history(); };
  // Page refresh: resume the server-side session; unfinished ones are never recorded as completed.
  const a = await api.get('/focus/active');
  if (a) { session = a; type = a.type; offset = a.serverNow - Date.now(); if (a.task) WZ.$('#task').value = a.task._id; WZ.$('#msg').textContent = 'Session restored.'; run(); if (remaining() <= 0 && !a.pausedAt) finish(); } else ui();
  await history();
});
