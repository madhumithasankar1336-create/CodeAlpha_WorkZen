(function () {
  const { esc } = WZ;
  WZ.openTask = async (id) => {
    let d;
    try { d = await api.get('/tasks/' + id); } catch (e) { return WZ.toast(e.message, 'error'); }
    const t = d.task;
    const m = WZ.modal(WZ.loader);
    const render = (d) => {
      const t = d.task;
      m.el.innerHTML = `<div class="row between"><h2>${esc(t.title)}</h2><button class="btn sm" data-x aria-label="Close">✕</button></div>
      <div class="row small muted">${WZ.prio(t.priority)}<span>📁 ${esc(t.project.name)}</span><span>Due ${WZ.date(t.dueDate)}</span>${t.overdue ? '<span class="pill s-bad">Overdue</span>' : ''}<span>Created by ${esc(t.creator ? t.creator.name : 'unknown')} · ${WZ.dt(t.createdAt)}</span></div>
      <p>${esc(t.description) || '<span class="muted">No description.</span>'}</p>
      <div class="grid g2" style="grid-template-columns:1fr 1fr"><div><label>Status</label><select id="st" ${d.canEdit ? '' : 'disabled'}>${['To Do', 'In Progress', 'In Review', 'Completed'].map((s) => `<option ${t.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      <div><label>Assignee ${d.canManage ? '' : '(owners/admins can reassign)'}</label><div class="row">${WZ.avatar(t.assignee)}<span>${esc(t.assignee ? t.assignee.name : 'Unassigned')}</span>${d.canManage ? '<button class="btn sm" id="re">Reassign</button>' : ''}</div></div></div>
      <div class="row mt">${d.canEdit ? '<button class="btn sm" id="ed">Edit</button>' : ''}${d.canEdit ? '<button class="btn sm danger" id="del">Delete</button>' : ''}</div>
      <h3 class="mt">Comments</h3><div class="list" id="cm">${d.comments.length ? d.comments.map((c) => `<div><div class="row small">${WZ.avatar(c.author, 22)}<b>${esc(c.author ? c.author.name : 'Deleted user')}</b><span class="muted">${WZ.dt(c.createdAt)}</span>${c.author && c.author._id === WZ.user._id || d.canManage ? `<button class="btn sm" data-dc="${c._id}">Delete</button>` : ''}</div><div>${esc(c.text)}</div></div>`).join('') : '<div class="muted">No comments yet.</div>'}</div>
      <form id="cf" class="row mt" style="flex-wrap:nowrap"><input name="text" placeholder="Write a comment…" maxlength="1000" required><button class="btn primary">Post</button></form>
      <h3 class="mt">Activity timeline</h3><div class="list small">${d.activity.length ? d.activity.map((a) => `<div>${esc(a.user ? a.user.name : 'Someone')} ${esc(a.action)} <span class="muted">· ${WZ.dt(a.createdAt)}</span></div>`).join('') : '<div class="muted">No activity yet.</div>'}</div>`;
      const q = (s) => m.el.querySelector(s), reload = async () => { try { render(await api.get('/tasks/' + id)); WZ.refresh(); } catch (e) { WZ.toast(e.message, 'error'); } };
      q('[data-x]').onclick = m.close; q('#cf').onsubmit = async (e) => { e.preventDefault(); try { await api.post(`/tasks/${id}/comments`, { text: e.target.text.value }); await reload(); } catch (x) { WZ.toast(x.message, 'error'); } };
      q('#st').onchange = async (e) => { try { await api.patch(`/tasks/${id}/status`, { status: e.target.value }); WZ.toast('Status updated', 'success'); await reload(); } catch (x) { WZ.toast(x.message, 'error'); e.target.value = t.status; } };
      m.el.querySelectorAll('[data-dc]').forEach((b) => (b.onclick = async () => { try { await api.del('/tasks/comments/' + b.dataset.dc); await reload(); } catch (x) { WZ.toast(x.message, 'error'); } }));
      if (q('#ed')) q('#ed').onclick = async () => { m.close(); await WZ.taskForm(t); };
      if (q('#del')) q('#del').onclick = async () => { if (!confirm('Delete this task and its comments?')) return; try { await api.del('/tasks/' + id); WZ.toast('Task deleted', 'success'); m.close(); WZ.refresh(); } catch (x) { WZ.toast(x.message, 'error'); } };
      if (q('#re')) q('#re').onclick = async () => {
        const p = (await WZ.projects(true)).find((x) => x._id === t.project._id);
        const box = document.createElement('div'); box.className = 'row mt';
        box.innerHTML = `<select id="na">${WZ.memberOptions(p, t.assignee && t.assignee._id)}</select><button class="btn primary sm">Confirm reassignment</button>`; q('#re').after(box);
        box.querySelector('button').onclick = async () => {
          const to = box.querySelector('select').value, name = box.querySelector('select').selectedOptions[0].textContent;
          if (!confirm(`Reassign "${t.title}" to ${name}?`)) return;
          try { await api.patch(`/tasks/${id}/assign`, { assignee: to || null, confirm: true }); WZ.toast('Task reassigned', 'success'); await reload(); } catch (x) { WZ.toast(x.message, 'error'); }
        };
      };
    };
    render(d);
  };
})();
