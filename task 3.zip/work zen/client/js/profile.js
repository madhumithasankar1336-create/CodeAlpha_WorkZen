WZ.init('profile', async (main) => {
  const { esc } = WZ, COLORS = ['#22D3EE', '#8B5CF6', '#F59E0B', '#10B981', '#EC4899', '#3B82F6'];
  const load = async () => {
    const d = await api.get('/users/me'), u = d.user;
    main.innerHTML = `<h1>Profile</h1><div class="grid g2"><div class="card"><div class="row">${WZ.avatar(u, 72)}<div><h2>${esc(u.name)}</h2><div class="muted">${esc(u.email)}</div><div class="small muted">Member since ${WZ.date(u.createdAt)}</div></div></div>
    <form id="pf" novalidate><label>Name</label><input name="name" maxlength="60" value="${esc(u.name)}"><label>Email (cannot be changed)</label><input value="${esc(u.email)}" disabled><label>Avatar color</label><div class="row">${COLORS.map((c) => `<label style="margin:0"><input type="radio" name="avatarColor" value="${c}" ${u.avatarColor === c ? 'checked' : ''} style="width:auto"> <span class="avatar" style="background:${c};width:24px;height:24px"></span></label>`).join('')}</div><div class="field-err" id="pe" role="alert"></div><button class="btn primary mt">Save changes</button></form></div>
    <div class="card"><h2>Your stats</h2><div class="grid g4" style="grid-template-columns:1fr 1fr"><div class="stat"><div class="v">${d.tasks.completed}</div><div class="l">Tasks completed</div></div><div class="stat"><div class="v">${d.tasks.assigned}</div><div class="l">Tasks assigned</div></div><div class="stat"><div class="v">${d.focus.sessions}</div><div class="l">Focus sessions</div></div><div class="stat"><div class="v">${d.focus.minutes}</div><div class="l">Focus minutes</div></div></div><h3 class="mt">Badges</h3>${d.badges.length ? '<div class="row">' + d.badges.map((b) => `<span class="pill s-ok" title="${esc(b.criteria)}">${b.icon} ${esc(b.name)}</span>`).join('') + '</div>' : '<p class="muted small">No badges yet — see <a href="achievements.html">Achievements</a>.</p>'}</div></div>`;
    const f = WZ.$('#pf');
    f.onsubmit = async (e) => { e.preventDefault(); const name = f.name.value.trim(); if (name.length < 2) return (WZ.$('#pe').textContent = 'Name must be at least 2 characters'); try { await api.put('/users/me', { name, avatarColor: f.avatarColor.value }); WZ.toast('Profile updated', 'success'); location.reload(); } catch (x) { WZ.$('#pe').textContent = x.message; } };
  };
  await load();
});
