WZ.init('tasks', async (main) => {
  const { esc } = WZ, projects = await WZ.projects(true);
  main.innerHTML = `<div class="row between"><div><h1>My Tasks</h1><p class="muted small">Smart Task Prioritizer — a transparent rule-based score (not an AI model). Each task shows why it was ranked.</p></div><button class="btn primary" id="nt">+ New task</button></div>
  <div class="toolbar"><input id="q" placeholder="Search tasks…"><select id="scope"><option value="1">Assigned to me</option><option value="">All tasks in my projects</option></select><select id="pr">${WZ.projectOptions(projects, '', 'All projects')}</select><select id="st"><option value="">Any status</option>${['To Do', 'In Progress', 'In Review', 'Completed'].map((s) => `<option>${s}</option>`).join('')}</select><select id="pri"><option value="">Any priority</option>${['Low', 'Medium', 'High', 'Urgent'].map((s) => `<option>${s}</option>`).join('')}</select><select id="sort"><option value="recommended">Sort: Recommended</option><option value="deadline">Sort: Deadline</option><option value="status">Sort: Status</option></select></div><div id="out">${WZ.loader}</div>`;
  const row = (t) => `<div class="card" style="padding:14px"><div class="row between"><div><a href="#" data-t="${t._id}"><b>${esc(t.title)}</b></a> ${WZ.prio(t.priority)} ${t.overdue ? '<span class="pill s-bad">Overdue</span>' : ''}<div class="small muted">${esc(t.project.name)} · ${esc(t.status)} · Due ${WZ.date(t.dueDate)} · score ${t.rec.score}</div></div><div>${WZ.avatar(t.assignee)}</div></div><div class="small muted mt">Why: ${esc(t.rec.reasons.join(' · '))}</div></div>`;
  const load = async () => {
    const v = (s) => WZ.$(s).value, sort = v('#sort');
    const tasks = await api.get('/tasks/prioritized', { mine: v('#scope'), project: v('#pr'), status: v('#st'), priority: v('#pri'), q: v('#q').trim(), sort });
    if (!tasks.length) { WZ.$('#out').innerHTML = WZ.empty('No tasks match. Try changing filters or add a task.'); return; }
    WZ.$('#out').innerHTML = sort === 'recommended' ? ['Do First', 'Due Soon', 'In Progress', 'Can Wait', 'Completed'].map((cat) => { const g = tasks.filter((t) => t.rec.category === cat); return g.length ? `<h2 class="mt">${cat} <span class="muted small">(${g.length})</span></h2><div class="grid">${g.map(row).join('')}</div>` : ''; }).join('') : `<div class="grid">${tasks.map(row).join('')}</div>`;
    WZ.$$('[data-t]', main).forEach((a) => (a.onclick = (e) => { e.preventDefault(); WZ.openTask(a.dataset.t); }));
  };
  WZ.$('#nt').onclick = () => WZ.taskForm();
  WZ.$$('select', main).forEach((s) => (s.onchange = () => load().catch((e) => WZ.toast(e.message, 'error')))); WZ.$('#q').oninput = WZ.debounce(load);
  await load(); WZ.live(load);
});
