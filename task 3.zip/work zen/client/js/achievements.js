WZ.init('achievements', async (main) => {
  const { esc } = WZ;
  const load = async () => {
    const d = await api.get('/insights/achievements');
    main.innerHTML = `<h1>Achievements</h1><div class="grid g4"><div class="card stat"><div class="v">🔥 ${d.streak.current}</div><div class="l">Current streak (days)</div></div><div class="card stat"><div class="v">${d.streak.longest}</div><div class="l">Longest streak</div></div><div class="card stat"><div class="v">${d.stats.today}</div><div class="l">Completed today</div></div><div class="card stat"><div class="v">${d.stats.week}</div><div class="l">Completed this week</div></div></div><p class="small muted mt">Streaks count days with a completed task or focus session, using the app timezone. Only tasks assigned to you that existed for at least a minute count, and duplicate titles are ignored.</p><div class="grid g3 mt">${d.badges.map((b) => `<div class="card badge-card ${b.earned ? '' : 'locked'}"><div class="ic">${b.icon}</div><h3>${esc(b.name)}</h3><p class="small muted">${esc(b.criteria)}</p>${b.earned ? `<span class="pill s-ok">Earned ${WZ.date(b.awardedAt)}</span>` : '<span class="pill p-low">Locked</span>'}</div>`).join('')}</div>`;
  };
  await load(); WZ.live(load);
});
