WZ.init('notifications', async (main) => {
  const { esc } = WZ; let only = false;
  main.innerHTML = `<div class="row between"><h1>Notifications</h1><div class="row"><button class="btn sm" id="f">Show unread only</button><button class="btn sm primary" id="all">Mark all as read</button></div></div><div id="out" class="mt">${WZ.loader}</div>`;
  const ICON = { task_assigned: '📌', task_updated: '🔄', comment: '💬', project_invite: '📨', deadline: '⏰', badge: '🏅' };
  const load = async () => {
    const d = await api.get('/notifications', { unread: only ? '1' : '' }); WZ.setUnread(d.unread);
    WZ.$('#out').innerHTML = d.items.length ? `<div class="card"><div class="list">${d.items.map((n) => `<div class="row between ${n.read ? '' : 'unread'}"><div>${ICON[n.type] || '🔔'} ${n.task ? `<a href="#" data-t="${n.task}" data-n="${n._id}">${esc(n.message)}</a>` : esc(n.message)}<div class="small muted">${WZ.dt(n.createdAt)}</div></div>${n.read ? '' : `<button class="btn sm" data-r="${n._id}">Mark read</button>`}</div>`).join('')}</div></div>` : WZ.empty(only ? 'No unread notifications.' : 'No notifications yet.');
    WZ.$$('[data-r]', main).forEach((b) => (b.onclick = async () => { try { await api.patch(`/notifications/${b.dataset.r}/read`); load(); } catch (e) { WZ.toast(e.message, 'error'); } }));
    WZ.$$('[data-t]', main).forEach((a) => (a.onclick = async (e) => { e.preventDefault(); try { await api.patch(`/notifications/${a.dataset.n}/read`); } catch { /* ignore */ } WZ.openTask(a.dataset.t); load(); }));
  };
  WZ.$('#all').onclick = async () => { try { await api.post('/notifications/read-all'); load(); } catch (e) { WZ.toast(e.message, 'error'); } };
  WZ.$('#f').onclick = (e) => { only = !only; e.target.textContent = only ? 'Show all' : 'Show unread only'; load(); };
  document.addEventListener('wz:notification', load);
  await load();
});
