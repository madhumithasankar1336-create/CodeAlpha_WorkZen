(function () {
  document.documentElement.dataset.theme = localStorage.getItem('wz_theme') || 'dark';
  document.getElementById('theme').onclick = () => { const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = t; localStorage.setItem('wz_theme', t); };
  api.get('/auth/me').then(() => { const l = document.getElementById('loginBtn'); l.textContent = 'Dashboard'; l.href = 'dashboard.html'; }).catch(() => {});
})();
