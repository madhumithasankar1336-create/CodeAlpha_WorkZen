WZ.init('team-pulse', async (main) => {
  const { esc } = WZ, projects = await WZ.projects(true);
  main.innerHTML = `<h1>Team Pulse</h1><p class="muted small">Informational activity indicators from your project data. They are not measures of individual performance.</p><div class="toolbar"><select id="pr">${WZ.projectOptions(projects, '', 'All projects')}</select><select id="days">${[7, 14, 30, 90].map((d) => `<option value="${d}">Last ${d} days</option>`).join('')}</select></div><div id="out">${WZ.loader}</div>`;
  const load = async () => {
    const d = await api.get('/insights/team-pulse', { project: WZ.$('#pr').value, days: WZ.$('#days').value }), s = d.summary;
    const stat = (v, l) => `<div class="card stat"><div class="v">${v}</div><div class="l">${l}</div></div>`;
    WZ.$('#out').innerHTML = `<div class="grid g4">${stat(s.completedInPeriod, `Completed (last ${d.days}d)`)}${stat(s.inProgress, 'In progress')}${stat(s.pending, 'Pending (To Do)')}${stat(s.overdue, 'Overdue')}</div>
    <div class="grid g2 mt"><div class="card"><h2>Project progress</h2>${d.projects.length ? d.projects.map((p) => `<div class="mt"><div class="row between"><a href="project-details.html?id=${p._id}">${esc(p.name)}</a><span class="small muted">${p.progress}% · health ${p.health == null ? 'n/a' : p.health}</span></div><div class="bar"><i style="width:${p.progress}%"></i></div></div>`).join('') : WZ.empty('No projects yet.')}</div>
    <div class="card"><h2>Member workload</h2>${d.workload.length ? `<table><tr><th>Member</th><th>Open</th><th>In progress</th><th>Done (period)</th><th>Overdue</th></tr>${d.workload.map((m) => `<tr><td>${WZ.avatar(m.user, 22)} ${esc(m.user.name)}</td><td>${m.open}</td><td>${m.inProgress}</td><td>${m.completedInPeriod}</td><td>${m.overdue}</td></tr>`).join('')}</table><p class="small muted">Listed alphabetically — counts alone say little about effort or impact.</p>` : WZ.empty('No assigned tasks yet.')}</div></div>
    <div class="card mt"><h2>Recent team activity</h2>${d.activity.length ? '<div class="list small">' + d.activity.map((a) => `<div>${WZ.avatar(a.user, 20)} <b>${esc(a.user ? a.user.name : 'Someone')}</b> ${esc(a.action)} <span class="muted">· ${esc(a.project ? a.project.name : '')} · ${WZ.ago(a.createdAt)}</span></div>`).join('') + '</div>' : WZ.empty('No activity in this period.')}</div>`;
  };
  WZ.$('#pr').onchange = load; WZ.$('#days').onchange = load; await load(); WZ.live(load);
});
