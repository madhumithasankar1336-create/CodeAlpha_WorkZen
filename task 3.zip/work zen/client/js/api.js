(function () {
  const csrf = () => decodeURIComponent((document.cookie.match(/(?:^|; )wz_csrf=([^;]*)/) || [])[1] || '');
  const qs = (o) => { const p = new URLSearchParams(); Object.entries(o || {}).forEach(([k, v]) => { if (v !== '' && v != null) p.set(k, v); }); const s = p.toString(); return s ? '?' + s : ''; };
  async function request(path, method = 'GET', body) {
    const opts = { method, credentials: 'same-origin', headers: {} };
    if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    if (method !== 'GET') opts.headers['x-csrf-token'] = csrf();
    let res;
    try { res = await fetch('/api' + path, opts); } catch { throw new Error('Cannot reach the server. Check your connection.'); }
    let json = {};
    try { json = await res.json(); } catch { /* non-JSON */ }
    if (!res.ok || json.success === false) { const e = new Error(json.message || 'Request failed (' + res.status + ')'); e.status = res.status; e.errors = json.errors; throw e; }
    return json.data;
  }
  window.api = {
    get: (p, q) => request(p + qs(q)), post: (p, b) => request(p, 'POST', b || {}), put: (p, b) => request(p, 'PUT', b || {}),
    patch: (p, b) => request(p, 'PATCH', b || {}), del: (p) => request(p, 'DELETE'),
  };
})();
