WZ.init('dashboard', async (main) => {
  const { esc } = WZ;
  const load = async () => {
    const d = await api.get('/insights/dashboard'), t = d.totals;
    const stat = (v, l) => `<div class="card stat"><div class="v">${v}</div><div class="l">${l}</div></div>`;
    main.innerHTML = `<div class="row between"><div><h1>Welcome back, ${esc(WZ.user.name.split(' ')[0])} 👋</h1><p class="muted">Plan Smarter. Collaborate Better. Achieve Together.</p></div></div>
    <div class="grid g4">${stat(t.projects, 'Total projects')}${stat(t.activeProjects, 'Active projects')}${stat(t.tasks, 'Total tasks')}${stat(t.completed, 'Completed')}${stat(t.pending, 'Pending')}${stat(t.overdue, 'Overdue')}</div>
    <div class="grid g3 mt">
      <div class="card"><h2>Overall completion</h2><div class="row" style="justify-content:center">${WZ.donut(t.completionPct, 140)}</div></div>
      <div class="card"><h2>Team productivity</h2><p class="muted small">Tasks completed, last 7 days</p>${WZ.bars(d.productivity.days.map((x) => ({ label: x.day, short: x.day.slice(8), value: x.completed })))}<p class="small muted">🔥 Streak: ${d.productivity.streak.current} day(s) · Longest ${d.productivity.streak.longest}</p></div>
      <div class="card"><h2>Focus sessions</h2><div class="row" style="gap:24px"><div class="stat"><div class="v">${d.focus.todaySessions}</div><div class="l">Today</div></div><div class="stat"><div class="v">${d.focus.todayMinutes}</div><div class="l">Minutes today</div></div><div class="stat"><div class="v">${d.focus.totalSessions}</div><div class="l">All time</div></div></div><a class="btn sm mt" href="focus-mode.html">Start focusing</a></div>
    </div>
    <div class="grid g2 mt">
      <div class="card"><h2>🎯 Do first</h2>${d.doFirst.length ? '<div class="list">' + d.doFirst.map((x) => `<div><a href="#" data-t="${x._id}"><b>${esc(x.title)}</b></a> ${WZ.prio(x.priority)}<div class="small muted">${esc(x.rec.reasons.join(' · '))}</div></div>`).join('') + '</div>' : WZ.empty('Nothing urgent assigned to you. Nice!')}</div>
      <div class="card"><h2>Upcoming deadlines (7 days)</h2>${d.upcoming.length ? '<div class="list">' + d.upcoming.map((x) => `<div class="row between"><a href="#" data-t="${x._id}">${esc(x.title)}</a><span class="pill ${x.daysLeft <= 1 ? 's-warn' : 's-info'}">${x.daysLeft === 0 ? 'Today' : x.daysLeft + 'd'}</span></div>`).join('') + '</div>' : WZ.empty('No deadlines in the next 7 days.')}</div>
      <div class="card"><h2>Recent activity</h2>${d.activity.length ? '<div class="list small">' + d.activity.map((a) => `<div>${WZ.avatar(a.user, 20)} <b>${esc(a.user ? a.user.name : 'Someone')}</b> ${esc(a.action)} <span class="muted">· ${esc(a.project ? a.project.name : '')} · ${WZ.ago(a.createdAt)}</span></div>`).join('') + '</div>' : WZ.empty('No activity yet. Create a project to get started.')}</div>
      <div class="card"><div class="row between"><h2>Notifications ${d.unread ? `<span class="pill s-bad">${d.unread}</span>` : ''}</h2><a href="notifications.html" class="small">View all</a></div>${d.notifications.length ? '<div class="list small">' + d.notifications.map((n) => `<div class="${n.read ? '' : 'unread'}">${esc(n.message)} <span class="muted">· ${WZ.ago(n.createdAt)}</span></div>`).join('') + '</div>' : WZ.empty('You are all caught up.')}</div>
    </div>`;
    WZ.$$('[data-t]', main).forEach((a) => (a.onclick = (e) => { e.preventDefault(); WZ.openTask(a.dataset.t); }));
  };
  await load(); WZ.live(load);
});
