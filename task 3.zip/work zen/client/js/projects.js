WZ.init('projects', async (main) => {
  const { esc } = WZ;
  main.innerHTML = `<div class="row between"><h1>Projects</h1><button class="btn primary" id="np">+ New project</button></div><div class="toolbar mt"><input id="q" placeholder="Search projects…" aria-label="Search"><select id="fs" aria-label="Status"><option value="">All statuses</option>${['Planning', 'Active', 'On Hold', 'Completed'].map((s) => `<option>${s}</option>`).join('')}</select></div><div id="list">${WZ.loader}</div>`;
  const load = async () => {
    const list = await WZ.projects(true).then(() => api.get('/projects', { q: WZ.$('#q').value.trim(), status: WZ.$('#fs').value }));
    WZ.$('#list').innerHTML = list.length ? `<div class="grid g3">${list.map((p) => `<div class="card"><div class="row between"><h2><a href="project-details.html?id=${p._id}">${esc(p.name)}</a></h2><span class="pill s-info">${esc(p.status)}</span></div><p class="muted small">${esc(p.description) || 'No description'}</p><div class="bar"><i style="width:${p.health.progress}%"></i></div><div class="row between small muted mt"><span>${p.health.progress}% complete · ${p.health.counts.total} tasks</span><span>Due ${WZ.date(p.deadline)}</span></div><div class="row between mt"><div class="row" style="gap:0">${p.members.slice(0, 5).map((m) => WZ.avatar(m.user, 26)).join('')}</div>${WZ.healthPill(p.health)}</div><div class="row mt"><a class="btn sm" href="project-details.html?id=${p._id}">Open</a>${p.myRole !== 'member' ? `<button class="btn sm" data-e="${p._id}">Edit</button>` : ''}${p.myRole === 'owner' ? `<button class="btn sm danger" data-d="${p._id}">Delete</button>` : ''}</div></div>`).join('')}</div>` : WZ.empty('No projects found. Create your first project!');
    WZ.$$('[data-e]').forEach((b) => (b.onclick = () => form(list.find((p) => p._id === b.dataset.e))));
    WZ.$$('[data-d]').forEach((b) => (b.onclick = async () => { const p = list.find((x) => x._id === b.dataset.d); if (!confirm(`Delete "${p.name}" and ALL its tasks, comments and activity? This cannot be undone.`)) return; try { await api.del('/projects/' + p._id); WZ.toast('Project deleted', 'success'); load(); } catch (e) { WZ.toast(e.message, 'error'); } }));
  };
  const form = (p) => {
    const m = WZ.modal(`<h2>${p ? 'Edit project' : 'New project'}</h2><form novalidate><label>Name</label><input name="name" maxlength="80" value="${esc(p ? p.name : '')}"><label>Description</label><textarea name="description" rows="3" maxlength="1000">${esc(p ? p.description : '')}</textarea><div class="grid g2" style="grid-template-columns:1fr 1fr;gap:0 12px"><div><label>Start date</label><input type="date" name="startDate" value="${p && p.startDate ? p.startDate.slice(0, 10) : ''}"></div><div><label>Deadline</label><input type="date" name="deadline" value="${p && p.deadline ? p.deadline.slice(0, 10) : ''}"></div></div><label>Status</label><select name="status">${['Planning', 'Active', 'On Hold', 'Completed'].map((s) => `<option ${(p ? p.status : 'Active') === s ? 'selected' : ''}>${s}</option>`).join('')}</select><div class="field-err" role="alert"></div><div class="row" style="justify-content:flex-end"><button type="button" class="btn" data-x>Cancel</button><button class="btn primary">Save</button></div></form>`);
    const f = WZ.$('form', m.el), err = WZ.$('.field-err', f); WZ.$('[data-x]', f).onclick = m.close;
    f.onsubmit = async (e) => {
      e.preventDefault(); err.textContent = '';
      const b = { name: f.name.value.trim(), description: f.description.value, startDate: f.startDate.value || null, deadline: f.deadline.value || null, status: f.status.value };
      if (b.name.length < 2) return (err.textContent = 'Project name must be at least 2 characters');
      if (b.startDate && b.deadline && b.deadline < b.startDate) return (err.textContent = 'Deadline cannot be before the start date');
      try { p ? await api.put('/projects/' + p._id, b) : await api.post('/projects', b); WZ.toast('Project saved', 'success'); m.close(); load(); } catch (ex) { err.textContent = ex.message; }
    };
  };
  WZ.$('#np').onclick = () => form(null);
  WZ.$('#q').oninput = WZ.debounce(load); WZ.$('#fs').onchange = load;
  await load(); WZ.live(load);
});
