(function () {
  const theme = localStorage.getItem('wz_theme') || 'dark'; // UI preference only; all data lives in MongoDB
  document.documentElement.dataset.theme = theme;
  const form = document.getElementById('authForm');
  if (!form) return;
  const isRegister = form.dataset.mode === 'register';
  const err = document.getElementById('formErr'), btn = form.querySelector('button[type=submit]');
  api.get('/auth/me').then(() => { location.href = 'dashboard.html'; }).catch(() => {});
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    const d = Object.fromEntries(new FormData(form));
    if (isRegister) {
      if (d.name.trim().length < 2) return (err.textContent = 'Name must be at least 2 characters');
      if (d.password.length < 8 || !/\d/.test(d.password) || !/[A-Za-z]/.test(d.password)) return (err.textContent = 'Password needs 8+ characters with a letter and a number');
      if (d.password !== d.confirm) return (err.textContent = 'Passwords do not match');
    }
    if (!/^\S+@\S+\.\S+$/.test(d.email)) return (err.textContent = 'Enter a valid email address');
    btn.disabled = true; btn.textContent = 'Please wait…';
    try {
      await api.post(isRegister ? '/auth/register' : '/auth/login', isRegister ? { name: d.name, email: d.email, password: d.password } : { email: d.email, password: d.password });
      location.href = 'dashboard.html';
    } catch (ex) { err.textContent = ex.message; btn.disabled = false; btn.textContent = isRegister ? 'Create account' : 'Log in'; }
  });
})();
